package com.shieldguard.app.data.api

import okhttp3.MediaType
import okhttp3.RequestBody
import okio.BufferedSink
import okio.ForwardingSource
import okio.Source
import java.io.IOException

/**
 * 带进度回调的 multipart 包装体（规范 6：上传用 CountingRequestBody 带进度回调）。
 * 通过底层 Source 计数，避免为每个 chunk 反射/缓存整个 body。
 */
class CountingRequestBody(
    private val delegate: RequestBody,
    private val onProgress: (written: Long, total: Long) -> Unit,
) : RequestBody() {

    override fun contentType(): MediaType? = delegate.contentType()
    override fun contentLength(): Long = delegate.contentLength()

    override fun writeTo(sink: BufferedSink) {
        val total = contentLength()
        val counting = object : ForwardingSource(sink.source) {
            var written = 0L
            @Throws(IOException::class)
            override fun read(sink: okio.Buffer, byteCount: Long): Long {
                val read = super.read(sink, byteCount)
                if (read > 0) {
                    written += read
                    try { onProgress(written, total) } catch (_: Throwable) { /* 进度回调绝不影响上传 */ }
                }
                return read
            }
        }
        sink.writeAll(counting)
    }
}
