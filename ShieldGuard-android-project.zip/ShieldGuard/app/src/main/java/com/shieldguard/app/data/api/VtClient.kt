package com.shieldguard.app.data.api

import com.shieldguard.app.core.SgLog
import com.shieldguard.app.data.prefs.SettingsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.decodeFromString
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * 统一处理 429 / 401 的拦截器（规范 6）：
 * - 429：读取 Retry-After 头，等待后原请求重试一次；
 * - 401：Key 失效 → 通知 SettingsRepository 轮换/停用 Key，重试一次。
 * 只重试一次，避免与本地令牌桶叠加造成请求风暴。
 */
class AuthRetryInterceptor(private val settings: SettingsRepository) : Interceptor {

    override fun intercept(chain: Interceptor.Chain): Response {
        var request = chain.request()
        var response = chain.proceed(request)

        if (response.code == 429) {
            val retryAfter = response.header("Retry-After")?.toLongOrNull()?.coerceIn(1L, 60L) ?: 20L
            SgLog.w("VtClient", "429 限速，等待 ${retryAfter}s 后重试")
            response.close()
            Thread.sleep(retryAfter * 1000)
            response = chain.proceed(request)
        } else if (response.code == 401) {
            SgLog.w("VtClient", "401 Key 失效，切换 Key 重试")
            response.close()
            // 挂起函数不能在拦截器线程直接用，runBlocking 于此处可接受（低频路径）
            kotlinx.coroutines.runBlocking { settings.onUnauthorized() }
            request = request.newBuilder()
                .header("x-apikey", kotlinx.coroutines.runBlocking { settings.currentApiKey() })
                .build()
            response = chain.proceed(request)
        }
        return response
    }
}

/**
 * VirusTotal v3 客户端。所有网络均在 Dispatchers.IO 执行。
 */
class VtClient(
    private val settings: SettingsRepository,
    private val tokenBucket: com.shieldguard.app.core.TokenBucket,
) {

    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .writeTimeout(180, TimeUnit.SECONDS) // 大 APK 上传耗时较长
        .addInterceptor { chain ->
            // 本地令牌桶：公益节点 4 次/分钟，超量时挂起等待而非失败
            kotlinx.coroutines.runBlocking { tokenBucket.acquire() }
            val req = chain.request().newBuilder()
                .header("Accept", "application/json")
                .apply {
                    // 已显式携带 x-apikey 的请求（如 Key 校验）不覆盖，否则注入当前配置 Key
                    if (chain.request().header("x-apikey") == null) {
                        header("x-apikey", kotlinx.coroutines.runBlocking { settings.currentApiKey() })
                    }
                }
                .build()
            chain.proceed(req)
        }
        .addInterceptor(AuthRetryInterceptor(settings))
        .build()

    private val jsonMedia = "application/json; charset=utf-8".toMediaType()

    private suspend fun execute(request: Request): Response = withContext(Dispatchers.IO) {
        client.newCall(request).execute()
    }

    private suspend fun bodyString(request: Request): String = execute(request).use { resp ->
        val body = resp.body?.string().orEmpty()
        if (!resp.isSuccessful) throw IOException("HTTP ${resp.code}: ${body.take(200)}")
        body
    }

    /** 上传 APK 文件，返回 analysis id（POST /files） */
    suspend fun uploadFile(file: File, onProgress: (Float) -> Unit = {}): String {
        val fileBody = file.asRequestBody("application/vnd.android.package-archive".toMediaType())
        val counting = CountingRequestBody(fileBody) { written, total ->
            if (total > 0) onProgress((written.toDouble() / total).toFloat().coerceIn(0f, 1f))
        }
        val part = MultipartBody.Part.createFormData("file", file.name, counting)
        val request = Request.Builder()
            .url("https://www.virustotal.com/api/v3/files")
            .post(MultipartBody.Builder().setType(MultipartBody.FORM).addPart(part).build())
            .build()
        val resp = bodyString(request)
        return json.decodeFromString<UploadResponse>(resp).data?.id
            ?: throw IOException("上传响应缺少 data.id")
    }

    /** 轮询分析直至 completed；退避 3s→5s→8s→12s…，最多 ~10 次 */
    suspend fun waitForAnalysis(analysisId: String, onTick: (String) -> Unit = {}): Stats {
        var delayMs = 3000L
        repeat(10) {
            val body = bodyString(
                Request.Builder()
                    .url("https://www.virustotal.com/api/v3/analyses/$analysisId")
                    .get().build()
            )
            val resp = json.decodeFromString<AnalysisResponse>(body)
            val status = resp.data?.attributes?.status
            onTick(status ?: "unknown")
            if (status == "completed") {
                return resp.data?.attributes?.stats ?: Stats()
            }
            kotlinx.coroutines.delay(delayMs)
            delayMs = (delayMs * 3 / 2).coerceAtMost(15000L)
        }
        throw IOException("分析超时，请稍后在扫描中心重试")
    }

    /** 只传哈希（隐私模式 / 64MB 超限回退）：GET /files/{sha256} */
    suspend fun fileReport(sha256: String): Stats? {
        val body = try {
            bodyString(
                Request.Builder()
                    .url("https://www.virustotal.com/api/v3/files/$sha256")
                    .get().build()
            )
        } catch (e: IOException) {
            if (e.message?.contains("404") == true) return null // VT 未收录
            throw e
        }
        return json.decodeFromString<FileReportResponse>(body).data?.attributes?.lastAnalysisStats
    }

    /** 校验 Key：GET /users/me，成功返回用户 id（设置页自定义 Key 校验） */
    suspend fun validateKey(key: String): String? {
        val request = Request.Builder()
            .url("https://www.virustotal.com/api/v3/users/me")
            .header("x-apikey", key)
            .header("Accept", "application/json")
            .get()
            .build()
        return execute(request).use { resp ->
            if (resp.code == 200) {
                json.decodeFromString<UserMeResponse>(resp.body?.string().orEmpty()).data?.id
            } else null
        }
    }

    /** 后台静默探测连通性，用于 UI 提示 */
    suspend fun healthy(): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            execute(
                Request.Builder().url("https://www.virustotal.com/api/v3/users/me").get().build()
            ).use { it.code != 0 }
        }.getOrDefault(false)
    }
}
