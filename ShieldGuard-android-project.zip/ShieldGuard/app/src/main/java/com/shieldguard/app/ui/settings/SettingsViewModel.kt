package com.shieldguard.app.ui.settings

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shieldguard.app.core.AppResult
import com.shieldguard.app.core.ServiceLocator
import com.shieldguard.app.core.SgLog
import com.shieldguard.app.core.runCatchingResult
import com.shieldguard.app.data.prefs.SortMode
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** 设置页 VM：API 配置校验 / DNS / 减弱动效 / QQ 群 */
class SettingsViewModel : ViewModel() {

    private val sl = ServiceLocator
    private val appContext = sl.appContext

    val useCustomKey = sl.settings.useCustomKey
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
    val privacyHashOnly = sl.settings.privacyHashOnly
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
    val reduceMotion = sl.settings.reduceMotion
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
    val dnsServer = sl.settings.dnsServer
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "52.80.60.30")

    /** Key 校验流程状态：null 空闲 / true 成功 / false 失败 */
    val keyValidation = MutableStateFlow<Boolean?>(null)
    val keyError = MutableStateFlow<String?>(null)

    val busy = MutableStateFlow(false)

    /**
     * 保存自定义 Key：先经 /users/me 校验，成功后 AES+Keystore 加密落 DataStore（规范 3）。
     */
    fun saveCustomKey(key: String) {
        val trimmed = key.trim()
        if (trimmed.length < 20) {
            keyValidation.value = false
            keyError.value = "Key 格式不正确（长度不足），请完整粘贴 VirusTotal API Key"
            return
        }
        busy.value = true
        viewModelScope.launch {
            // 网络全走 Dispatchers.IO + 统一 Result 封装
            val result: AppResult<String?> = runCatchingResult("校验请求失败，请检查网络") {
                withContext(Dispatchers.IO) { sl.vtClient.validateKey(trimmed) }
            }
            busy.value = false
            when (result) {
                is AppResult.Success -> if (result.data != null) {
                    sl.settings.setCustomKey(trimmed)
                    keyValidation.value = true
                    keyError.value = null
                } else {
                    keyValidation.value = false
                    keyError.value = "Key 校验失败（401/403）：请确认复制的是 VirusTotal 账户的 API Key"
                }
                is AppResult.Failure -> {
                    keyValidation.value = false
                    keyError.value = "校验请求失败：${result.message}"
                }
            }
        }
    }

    fun usePublicApi() {
        viewModelScope.launch { sl.settings.clearCustomKey() }
        keyValidation.value = null
        keyError.value = null
    }

    fun setPrivacyHashOnly(on: Boolean) = viewModelScope.launch { sl.settings.setPrivacyHashOnly(on) }
    fun setReduceMotion(on: Boolean) = viewModelScope.launch { sl.settings.setReduceMotion(on) }

    fun setDnsServer(addr: String) = viewModelScope.launch {
        val valid = addr.trim().matches(
            Regex("^((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)\\.){3}(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)$"),
        )
        if (valid) sl.settings.setDnsServer(addr.trim())
        else Toast.makeText(appContext, "IP 格式不正确", Toast.LENGTH_SHORT).show()
    }

    // ---------- QQ 交流群（规范 3） ----------

    fun joinQQGroup() {
        // 先尝试 mqq 系 URI 唤起 QQ
        try {
            appContext.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("mqqapi://card/show_pslcard?src_type=internal&version=1&uin=418916519&card_type=group&source=qrcode"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
            return
        } catch (t: Throwable) {
            SgLog.i("Settings", "QQ 未安装或唤起失败，降级复制群号")
        }
        copyAndToast("418916519", "未检测到 QQ，群号已复制，请手动添加")
    }

    fun copyGroupLink() {
        copyAndToast("https://qm.qq.com/cgi-bin/qm/qr?k=&jump_from=webapi&authKey=&uin=418916519", "加群链接已复制")
    }

    private fun copyAndToast(text: String, toast: String) {
        val cm = appContext.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("ShieldGuard", text))
        Toast.makeText(appContext, toast, Toast.LENGTH_LONG).show()
    }
}
