package com.shieldguard.app.core

import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * 令牌桶限流：VirusTotal 公益节点对个人 Key 限速 4 次/分钟。
 * 桶容量 4、每 15 秒补充 1 个令牌，不足时挂起等待（而非直接失败），
 * 保证扫描流程平滑但绝不打爆上游限速。
 */
class TokenBucket(
    private val capacity: Int = 4,
    refillIntervalMillis: Long = 60_000L / 4,
) {
    private val mutex = Mutex()
    private var tokens = capacity.toDouble()
    private var lastRefill = System.nanoTime()
    private val refillNanos = refillIntervalMillis * 1_000_000

    suspend fun acquire() {
        while (true) {
            val waitMillis = mutex.withLock {
                refill()
                if (tokens >= 1.0) {
                    tokens -= 1.0
                    return
                }
                // 距离下一个令牌的等待时间
                ((refillNanos - (System.nanoTime() - lastRefill)) / 1_000_000).coerceAtLeast(50L)
            }
            kotlinx.coroutines.delay(waitMillis)
        }
    }

    private fun refill() {
        val now = System.nanoTime()
        val elapsed = now - lastRefill
        if (elapsed >= refillNanos) {
            tokens = (tokens + elapsed / refillNanos).coerceAtMost(capacity.toDouble())
            lastRefill = now
        }
    }
}
