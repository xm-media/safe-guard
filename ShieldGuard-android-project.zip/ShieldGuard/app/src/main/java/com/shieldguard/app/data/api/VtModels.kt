package com.shieldguard.app.data.api

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/** VirusTotal v3 响应模型（kotlinx.serialization；混淆规则已保留 serializer） */
@Serializable
data class UploadResponse(val data: IdOnly? = null)

@Serializable
data class IdOnly(val id: String? = null, val type: String? = null)

@Serializable
data class AnalysisResponse(val data: AnalysisData? = null)

@Serializable
data class AnalysisData(val id: String? = null, val attributes: AnalysisAttributes? = null)

@Serializable
data class AnalysisAttributes(
    val status: String? = null, // queued / in_progress / completed
    val stats: Stats? = null,
)

@Serializable
data class Stats(
    val malicious: Int = 0,
    val suspicious: Int = 0,
    val harmless: Int = 0,
    val undetected: Int = 0,
    val timeout: Int = 0,
)

@Serializable
data class FileReportResponse(val data: FileData? = null)

@Serializable
data class FileData(val attributes: FileAttributes? = null)

@Serializable
data class FileAttributes(
    @SerialName("last_analysis_stats") val lastAnalysisStats: Stats? = null,
    @SerialName("last_analysis_date") val lastAnalysisDate: Long? = null,
)

@Serializable
data class UserMeResponse(val data: IdOnly? = null)
