package com.shieldguard.app.core

import kotlinx.coroutines.CancellationException

/**
 * 统一 Result 封装：所有网络 / IO 走该类型，UI 层只处理三种形态
 * （成功 / 可重试失败 / 不可重试失败），保证"错误态可重试"三态齐全。
 */
sealed interface AppResult<out T> {
    data class Success<T>(val data: T) : AppResult<T>
    data class Failure(
        val message: String,
        val cause: Throwable? = null,
        val retryable: Boolean = true,
    ) : AppResult<Nothing>

    val isSuccess: Boolean get() = this is Success

    inline fun <R> map(transform: (T) -> R): AppResult<R> = when (this) {
        is Success -> Success(transform(data))
        is Failure -> this
    }

    fun getOrNull(): T? = (this as? Success)?.data
}

/** 包装挂起代码块；取消异常必须原样抛出（为什么：吞掉 CancellationException 会破坏协程取消语义） */
suspend inline fun <T> runCatchingResult(fallbackMessage: String = "操作失败，请重试", crossinline block: suspend () -> T): AppResult<T> =
    try {
        AppResult.Success(block())
    } catch (ce: CancellationException) {
        throw ce
    } catch (t: Throwable) {
        AppResult.Failure(t.message ?: fallbackMessage, t, retryable = t is java.io.IOException)
    }
