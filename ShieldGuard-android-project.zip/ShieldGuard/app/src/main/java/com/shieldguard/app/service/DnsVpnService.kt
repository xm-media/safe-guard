package com.shieldguard.app.service

import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import com.shieldguard.app.core.ServiceLocator
import com.shieldguard.app.core.SgLog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.util.concurrent.ConcurrentHashMap

/**
 * 卡片 C「网页防护」：VpnService 建本地 Dummy TUN，仅做 DNS 转发。
 *
 * 设计要点（为什么这样建 TUN）：
 * - 不 addRoute(0.0.0.0/0)，只 addRoute(TUN_DNS/32)：系统 DNS 查询会被路由到 TUN 的
 *   虚拟 DNS 地址，普通流量完全不经 VPN，性能零损耗；
 * - 收到 DNS 请求后经 protect() 过的 socket 转发给真实 DNS，避免转发死循环。
 */
class DnsVpnService : LifecycleService() {

    companion object {
        const val TUN_DNS = "10.111.222.3"
        const val NOTIFICATION_ID = 1002

        private val stateFlow = MutableStateFlow(VpnState())
        val state: StateFlow<VpnState> get() = stateFlow

        fun start(context: Context) {
            ContextCompat.startForegroundService(context, Intent(context, DnsVpnService::class.java))
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, DnsVpnService::class.java))
        }
    }

    data class VpnState(
        val connected: Boolean = false,
        val connectedAt: Long = 0L,
        val dnsServer: String = "",
        /** 拦截计数占位（真实拦截策略后续版本接入） */
        val blockedCount: Long = 0L,
    )

    private var tun: ParcelFileDescriptor? = null
    @Volatile private var running = false

    override fun onCreate() {
        super.onCreate()
        AlertManager.ensureChannels(this)
        ServiceCompat.startForeground(
            this, NOTIFICATION_ID,
            androidx.core.app.NotificationCompat.Builder(this, AlertManager.CHANNEL_VPN)
                .setSmallIcon(com.shieldguard.app.R.drawable.ic_notification_shield)
                .setContentTitle("网页防护运行中")
                .setContentText("DNS 安全转发已接管")
                .setOngoing(true)
                .build(),
            if (Build.VERSION.SDK_INT >= 30) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0,
        )
        lifecycleScope.launch(Dispatchers.IO) { runVpn() }
    }

    override fun onDestroy() {
        running = false
        stateFlow.value = stateFlow.value.copy(connected = false)
        runCatching { tun?.close() }
        super.onDestroy()
    }

    private suspend fun runVpn() {
        val dns = ServiceLocator.settings.dnsServer.first()
        val vpnBuilder = android.net.VpnService.Builder()
            .setSession("安全护盾 · 网页防护")
            .setMtu(1500)
            .addAddress(TUN_DNS, 32)
            .addDnsServer(TUN_DNS)
            .addRoute(TUN_DNS, 32) // 仅捕获发往虚拟 DNS 的包
        val fd = try {
            vpnBuilder.establish()
        } catch (t: Throwable) {
            SgLog.e("DnsVpn", "establish 失败", t)
            null
        }
        if (fd == null) {
            stateFlow.value = stateFlow.value.copy(connected = false)
            stopSelf()
            return
        }
        tun = fd
        running = true
        stateFlow.value = VpnState(connected = true, connectedAt = System.currentTimeMillis(), dnsServer = dns)
        SgLog.i("DnsVpn", "TUN 已建立，DNS → $dns")

        val input = FileInputStream(fd.fileDescriptor)
        val output = FileOutputStream(fd.fileDescriptor)
        val socket = DatagramSocket().apply { protect(this) } // 防止转发流量再进 VPN
        // queryId → 客户端 (IP 4B + 端口 2B)，应答回写时恢复源地址
        val pending = ConcurrentHashMap<Int, ByteArray>()

        // 响应回写线程
        Thread {
            val buf = ByteArray(4096)
            while (running) {
                try {
                    val packet = DatagramPacket(buf, buf.size)
                    socket.receive(packet)
                    val dnsPayload = packet.data.copyOfRange(0, packet.length)
                    val origin = pending.remove(dnsPayload.queryId()) ?: continue
                    output.write(buildReplyPacket(dnsPayload, origin))
                    output.flush()
                } catch (t: Throwable) {
                    if (running) SgLog.w("DnsVpn", "响应回写异常：${t.message}")
                }
            }
        }.start()

        // 主循环：读 TUN → 过滤 UDP/53 → 转发
        val buffer = ByteArray(32767)
        while (running) {
            try {
                val length = input.read(buffer)
                if (length <= 0) continue
                val pkt = buffer.copyOf(length)
                val parsed = parseUdpDns(pkt) ?: continue
                val (clientIp, clientPort, dnsPayload) = parsed
                pending[dnsPayload.queryId()] = clientIp + byteArrayOf(
                    ((clientPort shr 8) and 0xFF).toByte(), (clientPort and 0xFF).toByte(),
                )
                socket.send(DatagramPacket(dnsPayload, dnsPayload.size, InetAddress.getByName(dns), 53))
            } catch (t: Throwable) {
                if (running) SgLog.w("DnsVpn", "读取异常：${t.message}")
            }
        }
        socket.close()
    }

    /** 解析 IPv4 包，仅放行发往虚拟 DNS:53 的 UDP；返回 (客户端IP, 客户端端口, DNS载荷) */
    private fun parseUdpDns(pkt: ByteArray): Triple<ByteArray, Int, ByteArray>? {
        if (pkt.size < 28) return null
        if ((pkt[0].toInt() shr 4) != 4) return null          // 仅 IPv4（IPv6 DNS 走系统原生路径）
        val ihl = (pkt[0].toInt() and 0x0F) * 4
        if (pkt[9].toInt() != 17) return null                 // 仅 UDP
        val udpStart = ihl
        val dstPort = ((pkt[udpStart + 2].toInt() and 0xFF) shl 8) or (pkt[udpStart + 3].toInt() and 0xFF)
        if (dstPort != 53) return null
        val udpLen = ((pkt[udpStart + 4].toInt() and 0xFF) shl 8) or (pkt[udpStart + 5].toInt() and 0xFF)
        if (udpLen < 8 || udpStart + udpLen > pkt.size) return null
        val clientIp = pkt.copyOfRange(12, 16)
        val srcPort = ((pkt[udpStart].toInt() and 0xFF) shl 8) or (pkt[udpStart + 1].toInt() and 0xFF)
        val dnsPayload = pkt.copyOfRange(udpStart + 8, udpStart + udpLen)
        return Triple(clientIp, srcPort, dnsPayload)
    }

    /** 组回包：IP 头(src=虚拟DNS, dst=客户端) + UDP 头(src=53, dst=客户端端口) + DNS 应答 */
    private fun buildReplyPacket(dnsPayload: ByteArray, origin: ByteArray): ByteArray {
        val clientIp = origin.copyOfRange(0, 4)
        val clientPort = ((origin[4].toInt() and 0xFF) shl 8) or (origin[5].toInt() and 0xFF)
        val udpTotal = 8 + dnsPayload.size
        val ipTotal = 20 + udpTotal
        val out = ByteArray(ipTotal)

        // UDP 头
        out[20] = 0; out[21] = 53                       // src port
        out[22] = ((clientPort shr 8) and 0xFF).toByte(); out[23] = (clientPort and 0xFF).toByte()
        out[24] = ((udpTotal shr 8) and 0xFF).toByte(); out[25] = (udpTotal and 0xFF).toByte()
        out[26] = 0; out[27] = 0                        // UDP 校验和置 0（IPv4 允许）
        dnsPayload.copyInto(out, 28)

        // IP 头
        out[0] = 0x45
        out[1] = 0
        out[2] = ((ipTotal shr 8) and 0xFF).toByte(); out[3] = (ipTotal and 0xFF).toByte()
        out[4] = 0; out[5] = 0; out[6] = 0x40; out[7] = 0 // DF
        out[8] = 64                                       // TTL
        out[9] = 17                                       // UDP
        out[12] = 10; out[13] = 111; out[14] = 222; out[15] = 3 // src = TUN_DNS
        clientIp.copyInto(out, 16)                        // dst = 客户端
        val checksum = ipChecksum(out, 20)
        out[10] = ((checksum shr 8) and 0xFF).toByte()
        out[11] = (checksum and 0xFF).toByte()
        return out
    }

    private fun ipChecksum(header: ByteArray, len: Int): Int {
        var sum = 0L
        var i = 0
        while (i < len) {
            sum += ((header[i].toInt() and 0xFF) shl 8) or (header[i + 1].toInt() and 0xFF)
            i += 2
        }
        while (sum shr 16 != 0L) sum = (sum and 0xFFFF) + (sum shr 16)
        return (sum.toInt().inv()) and 0xFFFF
    }

    private fun ByteArray.queryId(): Int = ((this[0].toInt() and 0xFF) shl 8) or (this[1].toInt() and 0xFF)
}

/**
 * DNS 可达性探测：启用 VPN 前对目标 DNS 发一条最小 A 查询，2.5s 超时。
 */
object DnsProber {
    fun probe(server: String, timeoutMs: Int = 2500): Boolean = try {
        val socket = DatagramSocket().apply { soTimeout = timeoutMs }
        socket.use {
            // 最小 DNS 查询：id=0x1234, RD=1, qdcount=1, qname=www.qq.com A
            val q = byteArrayOf(
                0x12, 0x34, 0x01, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                3, 'w'.code.toByte(), 3, 'w'.code.toByte(), 2, 'q'.code.toByte(), 1, 'q'.code.toByte(),
                3, 'c'.code.toByte(), 2, 'o'.code.toByte(), 2, 'm'.code.toByte(), 0,
                0, 1, 0, 1,
            )
            it.send(DatagramPacket(q, q.size, InetAddress.getByName(server), 53))
            val resp = ByteArray(512)
            it.receive(DatagramPacket(resp, resp.size))
            true
        }
    } catch (t: Throwable) {
        SgLog.w("DnsProber", "DNS $server 探测失败：${t.message}")
        false
    }
}
