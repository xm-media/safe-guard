package com.shieldguard.app.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import com.shieldguard.app.core.ServiceLocator
import com.shieldguard.app.core.SgLog
import com.shieldguard.app.data.db.Verdict
import com.shieldguard.app.data.repo.ScanRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * 卡片 A「实时防护」前台服务：
 * - 常驻通知显示监控时长与今日扫描数；
 * - 动态注册 PACKAGE_ADDED / PACKAGE_REPLACED（package scheme）监听新装应用；
 * - 命中后自动送检 VT，报毒即发告警并写日志。
 */
class ProtectionService : LifecycleService() {

    companion object {
        const val NOTIFICATION_ID = 1001

        /** 运行状态 / 监控起点：HomeViewModel 直接订阅 */
        val running = kotlinx.coroutines.flow.MutableStateFlow(false)
        val startedAt = kotlinx.coroutines.flow.MutableStateFlow(0L)

        fun start(context: Context) {
            ContextCompat.startForegroundService(context, Intent(context, ProtectionService::class.java))
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, ProtectionService::class.java))
        }
    }

    private val packageReceiver = PackageChangeReceiver()

    override fun onCreate() {
        super.onCreate()
        startedAt.value = System.currentTimeMillis()
        AlertManager.ensureChannels(this)

        // 前台通知：dataSync 类型在 29+ 必须显式声明，避免系统校验崩溃
        ServiceCompat.startForeground(
            this, NOTIFICATION_ID,
            AlertManager.protectionNotification(this, formatDuration(0), todayScanCount()),
            if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0,
        )

        // 只在防护运行时监听安装广播（为什么动态注册：静态注册自 3.1 起收不到隐式 PACKAGE_XXX）
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        // PACKAGE_* 为受保护系统广播，EXPORTED 标志不影响安全性，但 34+ 注册时必须显式指定
        ContextCompat.registerReceiver(
            this, packageReceiver, filter, ContextCompat.RECEIVER_EXPORTED,
        )
        running.value = true

        // 每 30s 刷新常驻通知（监控时长 / 今日扫描数）
        lifecycleScope.launch {
            while (isActive) {
                delay(30_000)
                val nm = getSystemService(NOTIFICATION_SERVICE) as android.app.NotificationManager
                nm.notify(
                    NOTIFICATION_ID,
                    AlertManager.protectionNotification(this@ProtectionService, formatDuration(elapsed()), todayScanCount()),
                )
            }
        }
        SgLog.i("ProtectionService", "实时防护已启动")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        return android.app.Service.START_STICKY
    }

    override fun onDestroy() {
        running.value = false
        startedAt.value = 0L
        unregisterReceiver(packageReceiver)
        SgLog.i("ProtectionService", "实时防护已停止")
        super.onDestroy()
    }

    private fun elapsed(): Long = System.currentTimeMillis() - startedAt.value

    private fun todayScanCount(): Int =
        ServiceLocator.db.scanResultDao().let { dao ->
            kotlinx.coroutines.runBlocking { dao.countSince(ScanRepository.startOfDay()) }
        }

    private fun formatDuration(millis: Long): String {
        val totalMin = millis / 60_000
        val h = totalMin / 60
        val m = totalMin % 60
        return if (h > 0) "${h} 小时 $m 分钟" else "$m 分钟"
    }
}

/**
 * 新装应用监听：取 APK File(sourceDir) → 上传 VT → 轮询 → 报毒告警 + 写日志。
 * 全程走令牌桶（4 次/分钟），失败由 ScanWorker 落库重试。
 */
class PackageChangeReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        if (action != Intent.ACTION_PACKAGE_ADDED && action != Intent.ACTION_PACKAGE_REPLACED) return
        // goAsync：扫描是长耗时网络操作，必须延长 receiver 生命周期
        val pending = goAsync()
        ServiceLocator.applicationScope.launch {
            try {
                val pkg = intent.data?.schemeSpecificPart ?: return@launch
                scanNewInstall(context, pkg, replacing = action == Intent.ACTION_PACKAGE_REPLACED)
            } catch (t: Throwable) {
                SgLog.e("PackageReceiver", "新装应用送检失败", t)
            } finally {
                pending.finish()
            }
        }
    }

    private suspend fun scanNewInstall(context: Context, pkg: String, replacing: Boolean) {
        val sl = ServiceLocator
        val pm = context.packageManager
        val appInfo = try {
            pm.getApplicationInfo(pkg, 0)
        } catch (e: PackageManager.NameNotFoundException) {
            return
        }
        val sourceDir = appInfo.sourceDir ?: return
        val key = "pkg:$pkg"
        SgLog.i("PackageReceiver", "检测到${if (replacing) "更新" else "新装"}应用：$pkg")

        val result = sl.scanRepository.scanTarget(key)
            ?: run {
                // 首次直扫失败（常见于 sourceDir 暂不可读），落库交给 WorkManager 指数退避兜底
                sl.scanRepository.enqueue(listOf(key))
                return
            }
        if (result.verdict != Verdict.MALICIOUS) return

        val installSource = try {
            pm.getInstallSourceInfo(pkg).initiatingPackageName ?: "未知来源"
        } catch (e: Exception) {
            "未知来源"
        }
        val info = AlertManager.AlertInfo(
            packageName = pkg,
            installSource = installSource,
            engineHits = result.malicious,
            sha256 = result.sha256,
        )
        // 告警 + 日志写入（日志无论通知是否可见都要落库）
        AlertManager.writeLog(context, info, sl.scanRepository.vtLinkOf(result.sha256))
        AlertManager.fire(context, info)
    }
}
