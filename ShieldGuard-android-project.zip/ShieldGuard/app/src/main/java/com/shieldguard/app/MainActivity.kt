package com.shieldguard.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.lifecycleScope
import com.shieldguard.app.core.ServiceLocator
import com.shieldguard.app.ui.components.LocalReduceMotion
import com.shieldguard.app.ui.nav.ShieldNav
import com.shieldguard.app.ui.theme.ShieldGuardTheme
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import android.provider.Settings as SysSettings

class MainActivity : ComponentActivity() {

    private val reduceMotionFlow = MutableStateFlow(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // 动效降级判定（规范 5.5）：应用内"减弱动效"开关 ∥ 系统"移除动画"（ANIMATOR_DURATION_SCALE=0）
        lifecycleScope.launch {
            ServiceLocator.settings.reduceMotion
                .combine(reduceMotionFlow) { inApp, _ -> inApp }
                .collect { inApp ->
                    val systemOff = SysSettings.getFloat(
                        contentResolver, SysSettings.ANIMATOR_DURATION_SCALE, 1f,
                    ) == 0f
                    reduceMotionFlow.value = inApp || systemOff
                }
        }
        // 初始快照（首帧即正确）
        lifecycleScope.launch {
            reduceMotionFlow.value = ServiceLocator.settings.reduceMotion.first() ||
                SysSettings.getFloat(contentResolver, SysSettings.ANIMATOR_DURATION_SCALE, 1f) == 0f
        }

        setContent {
            ShieldGuardTheme {
                val reduceMotion by reduceMotionFlow.collectAsState()
                CompositionLocalProvider(LocalReduceMotion provides reduceMotion) {
                    ShieldNav()
                }
            }
        }
    }
}
