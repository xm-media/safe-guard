package com.shieldguard.app.core

import android.app.Application
import android.content.Context
import com.shieldguard.app.data.api.VtClient
import com.shieldguard.app.data.db.AppDatabase
import com.shieldguard.app.data.prefs.SettingsRepository
import com.shieldguard.app.data.repo.ScanRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

/**
 * 轻量服务定位器（不引入 Hilt，保持工程精简）。
 * 全部单例按需惰性创建，应用进程内共享。
 */
object ServiceLocator {

    lateinit var appContext: Context
        private set

    /** 应用级协程作用域：Receiver / Service 里的后台扫描都在此跑，与界面生命周期解耦 */
    val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val settings: SettingsRepository by lazy { SettingsRepository(appContext) }
    val db: AppDatabase by lazy { AppDatabase.create(appContext) }
    val tokenBucket: TokenBucket by lazy { TokenBucket() }
    val vtClient: VtClient by lazy { VtClient(settings, tokenBucket) }
    val scanRepository: ScanRepository by lazy { ScanRepository(appContext, db, vtClient, settings) }

    fun init(application: Application) {
        appContext = application.applicationContext
    }
}
