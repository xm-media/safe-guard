package com.shieldguard.app.ui.nav

import androidx.compose.animation.AnimatedVisibilityScope
import androidx.compose.animation.ExperimentalSharedTransitionApi
import androidx.compose.animation.SharedTransitionLayout
import androidx.compose.animation.SharedTransitionScope
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.shieldguard.app.ui.alerts.AlertsScreen
import com.shieldguard.app.ui.components.GlassBottomBar
import com.shieldguard.app.ui.home.HomeScreen
import com.shieldguard.app.ui.scan.ScanCenterScreen
import com.shieldguard.app.ui.settings.SettingsScreen

// ---------- 共享元素转场基础设施（规范 1：共享元素 + spring dampingRatio 0.6） ----------
@OptIn(ExperimentalSharedTransitionApi::class)
val LocalSharedTransitionScope = staticCompositionLocalOf<SharedTransitionScope?> { null }
val LocalNavAnimatedVisibilityScope = compositionLocalOf<AnimatedVisibilityScope?> { null }

/** 声明式共享元素标记；不在转场上下文时安全退化为普通 Modifier */
@OptIn(ExperimentalSharedTransitionApi::class)
@Composable
fun Modifier.sgSharedElement(key: String): Modifier {
    val sts = LocalSharedTransitionScope.current ?: return this
    val avs = LocalNavAnimatedVisibilityScope.current ?: return this
    return with(sts) {
        this@sgSharedElement.sharedElement(
            rememberSharedContentState(key),
            animatedVisibilityScope = avs,
        )
    }
}

@OptIn(ExperimentalSharedTransitionApi::class)
@Composable
fun ShieldNav() {
    val nav: NavHostController = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route ?: "home"
    val topLevel = currentRoute == "home" || currentRoute == "settings"

    SharedTransitionLayout {
        CompositionLocalProvider(LocalSharedTransitionScope provides this) {
            Box(Modifier.fillMaxSize()) {
                AppBackdrop()
                Scaffold(
                    containerColor = Color.Transparent,
                    bottomBar = {
                        if (topLevel) {
                            GlassBottomBar(
                                currentRoute = currentRoute,
                                scrollParallax = HomeScrollParallaxStore.parallax,
                                onNavigate = { route ->
                                    if (route != currentRoute) {
                                        nav.navigate(route) {
                                            popUpTo("home") { saveState = true }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    }
                                },
                            )
                        }
                    },
                ) { padding ->
                    NavHost(
                        nav,
                        startDestination = "home",
                        modifier = Modifier.fillMaxSize().padding(padding),
                        // spring(0.6) 转场，杜绝生硬切页
                        enterTransition = {
                            slideInHorizontally(
                                spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessMediumLow),
                            ) { it / 4 } + fadeIn(tween(200))
                        },
                        exitTransition = { fadeOut(tween(160)) },
                        popEnterTransition = {
                            slideInHorizontally(
                                spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessMediumLow),
                            ) { -it / 4 } + fadeIn(tween(200))
                        },
                        popExitTransition = {
                            slideOutHorizontally(
                                spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessMediumLow),
                            ) { it / 4 } + fadeOut(tween(160))
                        },
                    ) {
                        composable("home") {
                            CompositionLocalProvider(LocalNavAnimatedVisibilityScope provides this) {
                                HomeScreen(
                                    onOpenScanCenter = { nav.navigate("scan") },
                                    onOpenAlerts = { nav.navigate("alerts") },
                                )
                            }
                        }
                        composable("settings") {
                            CompositionLocalProvider(LocalNavAnimatedVisibilityScope provides this) {
                                SettingsScreen()
                            }
                        }
                        composable("scan") {
                            CompositionLocalProvider(LocalNavAnimatedVisibilityScope provides this) {
                                ScanCenterScreen(onBack = { nav.popBackStack() })
                            }
                        }
                        composable("alerts") {
                            CompositionLocalProvider(LocalNavAnimatedVisibilityScope provides this) {
                                AlertsScreen(onBack = { nav.popBackStack() })
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * 全局环境背景：冷色渐变 + 顶部环境光晕。
 * 玻璃卡片的后景采样与此渐变同源（GlassCard 内以 RenderEffect 模糊重建），
 * 保证毛玻璃观感一致。
 */
@Composable
fun AppBackdrop() {
    // 深浅色自适应（规范：全局深浅色自适应）
    val gradient = if (isSystemInDarkTheme()) {
        listOf(Color(0xFF0C1020), Color(0xFF141A2E), Color(0xFF161226))
    } else {
        listOf(Color(0xFFDDE7FB), Color(0xFFEDF1FA), Color(0xFFE3D9F6))
    }
    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(gradient, startY = 0f, endY = 2600f),
            ),
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        listOf(Color(0x526FD8FF), Color.Transparent),
                        center = Offset(120f, 80f),
                        radius = 900f,
                    ),
                ),
        )
    }
}

/** 首页滚动视差状态仓：HomeScreen 滚动时写入，底部导航读取产生高光位移 */
object HomeScrollParallaxStore {
    var parallax by mutableFloatStateOf(0f)
}
