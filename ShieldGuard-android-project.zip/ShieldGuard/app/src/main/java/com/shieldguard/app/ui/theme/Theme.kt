package com.shieldguard.app.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// ---- 品牌色：冷色玻璃基调 + 三档判定色 ----
val BrandBlue = Color(0xFF3D7BFF)
val BrandCyan = Color(0xFF6FD8FF)
val SafeGreen = Color(0xFF34C77B)
val WarnYellow = Color(0xFFF2B705)
val DangerRed = Color(0xFFE5484D)
val ShieldAmber = Color(0xFFFFB74D)

private val LightColors = lightColorScheme(
    primary = BrandBlue,
    secondary = BrandCyan,
    surface = Color(0xFFF4F6FC),
    background = Color(0xFFEDF1FA),
    onBackground = Color(0xFF1A2136),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF7DA6FF),
    secondary = BrandCyan,
    surface = Color(0xFF141A2E),
    background = Color(0xFF0C1020),
    onBackground = Color(0xFFE6EAF6),
)

/** 深浅色自适应（跟随系统），全局 Material3 */
@Composable
fun ShieldGuardTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = ShieldTypography,
        content = content,
    )
}

private val ShieldTypography = Typography(
    titleLarge = TextStyle(fontWeight = FontWeight.Bold, fontSize = 22.sp, lineHeight = 28.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 17.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 21.sp),
    labelMedium = TextStyle(fontSize = 12.sp, lineHeight = 16.sp),
)

/** API 31+ 才有 RenderEffect；用于玻璃材质降级判断（规范 5.5） */
val canUseRenderEffect: Boolean get() = Build.VERSION.SDK_INT >= 31
