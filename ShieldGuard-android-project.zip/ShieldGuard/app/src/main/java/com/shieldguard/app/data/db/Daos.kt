package com.shieldguard.app.data.db

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ScanResultDao {
    @Query("SELECT * FROM scan_results WHERE targetKey = :key")
    suspend fun byKey(key: String): ScanResultEntity?

    @Query("SELECT * FROM scan_results WHERE scannedAt >= :since")
    suspend fun since(since: Long): List<ScanResultEntity>

    @Query("SELECT COUNT(*) FROM scan_results WHERE scannedAt >= :since")
    suspend fun countSince(since: Long): Int

    @Query("SELECT * FROM scan_results ORDER BY scannedAt DESC")
    fun all(): Flow<List<ScanResultEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(result: ScanResultEntity)
}

@Dao
interface AlertLogDao {
    @Insert
    suspend fun insert(log: AlertLogEntity): Long

    @Query("SELECT * FROM alert_logs ORDER BY detectedAt DESC LIMIT 200")
    fun all(): Flow<List<AlertLogEntity>>

    @Query("SELECT * FROM alert_logs WHERE seen = 0 ORDER BY detectedAt DESC LIMIT 1")
    fun latestUnseen(): Flow<AlertLogEntity?>

    @Query("UPDATE alert_logs SET seen = 1 WHERE id = :id")
    suspend fun markSeen(id: Long)

    @Query("DELETE FROM alert_logs")
    suspend fun clear()
}

@Dao
interface ScanTaskDao {
    @Insert
    suspend fun insert(task: ScanTaskEntity): Long

    @Update
    suspend fun update(task: ScanTaskEntity)

    @Query("SELECT * FROM scan_tasks WHERE id = :id")
    suspend fun byId(id: Long): ScanTaskEntity?

    @Query("SELECT * FROM scan_tasks ORDER BY createdAt DESC LIMIT 100")
    fun all(): Flow<List<ScanTaskEntity>>

    @Query("DELETE FROM scan_tasks WHERE status = 2 AND createdAt < :before")
    suspend fun cleanDone(before: Long)
}

@Dao
interface PickedApkDao {
    @Query("SELECT * FROM picked_apks ORDER BY pickedAt DESC")
    fun all(): Flow<List<PickedApkEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<PickedApkEntity>)

    @Query("DELETE FROM picked_apks WHERE uriString = :uri")
    suspend fun delete(uri: String)
}

@Database(
    entities = [ScanResultEntity::class, AlertLogEntity::class, ScanTaskEntity::class, PickedApkEntity::class],
    version = 1,
    exportSchema = false,
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun scanResultDao(): ScanResultDao
    abstract fun alertLogDao(): AlertLogDao
    abstract fun scanTaskDao(): ScanTaskDao
    abstract fun pickedApkDao(): PickedApkDao

    companion object {
        fun create(context: Context): AppDatabase =
            Room.databaseBuilder(context, AppDatabase::class.java, "shieldguard.db")
                .fallbackToDestructiveMigration()
                .build()
    }
}
