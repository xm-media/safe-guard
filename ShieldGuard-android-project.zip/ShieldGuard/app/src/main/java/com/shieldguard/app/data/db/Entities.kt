package com.shieldguard.app.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

/** 判定等级：0 安全 / 1 可疑 / 2 报毒 */
object Verdict {
    const val SAFE = 0
    const val SUSPICIOUS = 1
    const val MALICIOUS = 2
}

/**
 * 扫描结果：以 targetKey（"pkg:xxx" 或 "uri:xxx"）为业务主键，
 * 24h 内同 sha256 直接命中缓存，不重复上传（规范：算 SHA-256 查本地缓存）。
 */
@Entity(tableName = "scan_results")
data class ScanResultEntity(
    @PrimaryKey val targetKey: String,
    val displayName: String,
    val sha256: String,
    val verdict: Int,
    val malicious: Int = 0,
    val suspicious: Int = 0,
    val harmless: Int = 0,
    val sizeBytes: Long = 0,
    val scannedAt: Long = System.currentTimeMillis(),
    /** true=来自「选择安装包」的 content uri，可提供安装按钮 */
    val isApkFile: Boolean = false,
)

/** 告警日志：新装应用命中恶意引擎后写入 */
@Entity(tableName = "alert_logs")
data class AlertLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val packageName: String,
    val installSource: String,
    val engineHits: Int,
    val sha256: String,
    val vtUrl: String,
    val detectedAt: Long = System.currentTimeMillis(),
    val seen: Boolean = false,
)

/** 扫描任务队列：失败落库，由 WorkManager 指数退避重试 */
@Entity(tableName = "scan_tasks")
data class ScanTaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val targetKey: String,        // "pkg:<package>" 或 "uri:<content uri>"
    val displayName: String,
    val sizeBytes: Long = 0,
    val status: Int = STATUS_QUEUED, // 0 排队 1 进行中 2 完成 3 失败
    val attempts: Int = 0,
    val createdAt: Long = System.currentTimeMillis(),
) {
    companion object {
        const val STATUS_QUEUED = 0
        const val STATUS_RUNNING = 1
        const val STATUS_DONE = 2
        const val STATUS_FAILED = 3
    }
}

/** 用户在「选择安装包」里挑过的 APK（持久化 URI，进程重启仍可读） */
@Entity(tableName = "picked_apks")
data class PickedApkEntity(
    @PrimaryKey val uriString: String,
    val displayName: String,
    val sizeBytes: Long,
    val sourceHint: String,
    val pickedAt: Long = System.currentTimeMillis(),
)
