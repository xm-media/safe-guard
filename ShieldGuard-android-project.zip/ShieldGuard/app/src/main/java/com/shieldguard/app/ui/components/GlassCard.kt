package com.shieldguard.app.ui.components

import android.graphics.RenderEffect
import android.graphics.Shader
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.shieldguard.app.ui.theme.canUseRenderEffect
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.sin

/**
 * 「减弱动效」全局开关（规范 5.5）：
 * 用户设置 或 系统"移除动画"(ANIMATOR_DURATION_SCALE=0) 任一命中即降级为静态玻璃。
 */
val LocalReduceMotion = staticCompositionLocalOf { false }

/** EmphasizedDecelerate（规范 5.2/5.4 指定曲线） */
val EmphasizedDecelerate = CubicBezierEasing(0.05f, 0.7f, 0.1f, 1f)

/**
 * GlassCard 公共液态玻璃材质（规范 5.1 / 5.2 / 5.3）。
 *
 * 性能设计（规范 5.5）：所有循环动画（荧光描边 dash offset、Liquid 光斑漂移）
 * 的动画 State 一律在 draw 阶段读取，配合 drawWithContent 只触发重绘、
 * 不触发 recomposition，稳定 60fps。
 */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 26.dp,
    glowing: Boolean = false,
    glowColor: Color = Color(0xFF34C77B),
    /** 状态变更触发 300ms 涟漪扩散 + 边缘折射闪烁（传任意可变状态 key） */
    pulseKey: Any? = null,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    val reduce = LocalReduceMotion.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scope = rememberCoroutineScope()

    // 按压 spring（dampingRatio 0.6，规范 1）
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.98f else 1f,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessMediumLow),
        label = "glassPressScale",
    )
    val corner by animateDpAsState(
        targetValue = if (pressed) cornerRadius - 4.dp else cornerRadius,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessMediumLow),
        label = "glassPressCorner",
    )

    // 状态变更涟漪（300ms，EmphasizedDecelerate）
    val ripple = remember { Animatable(0f) }
    if (!reduce && pulseKey != null) {
        LaunchedEffect(pulseKey) {
            ripple.snapTo(0f)
            ripple.animateTo(1f, tween(300, easing = EmphasizedDecelerate))
        }
    }

    // Liquid Layer 触摸弹簧跟随：滑动时向触摸点偏移，松手缓归
    val liquidOffset = remember { Animatable(Offset.Zero) }
    val dragModifier = if (reduce) Modifier else Modifier.pointerInput(Unit) {
        detectDragGestures(
            onDragEnd = {
                scope.launch { liquidOffset.animateTo(Offset.Zero, spring(dampingRatio = 0.6f)) }
            },
        ) { change, dragAmount ->
            change.consume()
            scope.launch { liquidOffset.snapTo(liquidOffset.value + dragAmount * 0.25f) }
        }
    }

    // 荧光描边 dash offset 循环：State 在 draw 阶段读取
    val glowTransition = rememberInfiniteTransition(label = "glow")
    val glowPhase by glowTransition.animateFloat(
        0f, 38f,
        infiniteRepeatable(tween(1200, easing = LinearEasing), RepeatMode.Restart),
        label = "glowPhase",
    )

    val shape = RoundedCornerShape(corner)
    Column(
        modifier
            .graphicsLayer {
                scaleX = scale; scaleY = scale
                shape = shape
                shadowElevation = 8.dp.toPx()
                // 彩色环境光阴影（光源左上 45°）
                ambientShadowColor = Color(0x4C3D7BFF)
                spotShadowColor = Color(0x2E1B2F6E)
            }
            .clip(shape)
            .background(Color.White.copy(alpha = 0.14f), shape) // 背景 alpha 0.12~0.18
            .then(if (onClick != null) Modifier.clickable(interactionSource = interaction, indication = null, onClick = onClick) else Modifier)
            .then(dragModifier)
            .drawWithContent {
                // ---- API31+：RenderEffect 模糊环境层（后景采样近似，见类注释）----
                if (!reduce && canUseRenderEffect) {
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(Color(0xFF3D7BFF).copy(alpha = 0.22f), Color.Transparent),
                            center = Offset(size.width * 0.2f, 0f),
                            radius = size.width,
                        ),
                        radius = size.width,
                        center = Offset(size.width * 0.2f, 0f),
                        blendMode = BlendMode.Overlay,
                    )
                }
                drawContent()

                // ---- 0.5~1dp 渐变描边：左上 alpha 0.5 → 右下 0.08 ----
                drawRoundRect(
                    brush = Brush.linearGradient(
                        colors = listOf(Color.White.copy(alpha = 0.5f), Color.White.copy(alpha = 0.08f)),
                        start = Offset.Zero,
                        end = Offset(size.width, size.height),
                    ),
                    cornerRadius = CornerRadius(corner.toPx()),
                    style = Stroke(width = 0.75.dp.toPx()),
                )
                // ---- 顶部白色内发光 alpha 0.15→0 ----
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(Color.White.copy(alpha = 0.15f), Color.Transparent),
                        startY = 0f,
                        endY = size.height * 0.28f,
                    ),
                )
                // ---- 状态变更涟漪：300ms 边缘折射闪烁 ----
                if (ripple.value > 0f) {
                    drawRoundRect(
                        brush = Brush.linearGradient(
                            listOf(Color.White.copy(alpha = 0.35f * (1f - ripple.value)), Color.Transparent),
                        ),
                        cornerRadius = CornerRadius(corner.toPx()),
                        style = Stroke(width = (1f + 3f * (1f - ripple.value)).dp.toPx()),
                    )
                }
                // ---- 5.3：开启态 = 绿色流动荧光描边（dash offset 循环）----
                if (glowing) {
                    val phase = if (reduce) 0f else glowPhase
                    drawRoundRect(
                        brush = Brush.linearGradient(
                            listOf(glowColor.copy(alpha = 0.9f), glowColor.copy(alpha = 0.25f)),
                        ),
                        cornerRadius = CornerRadius(corner.toPx()),
                        style = Stroke(
                            width = 1.5.dp.toPx(),
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(24f, 14f), phase),
                        ),
                    )
                }
            },
    ) {
        // Liquid Layer 光斑层
        LiquidLayer(reduce = reduce, touchOffset = liquidOffset, modifier = Modifier.matchParentSize())
        content()
    }
}

/**
 * Liquid Layer（规范 5.2）：2~3 个径向渐变光斑沿 Lissajous 路径漂移（周期 8~15s），
 * Screen 混合，alpha 0.06~0.12；滑动时向触摸点弹簧跟随，松手缓归。
 */
@Composable
fun LiquidLayer(
    reduce: Boolean,
    touchOffset: Animatable<Offset, *>,
    modifier: Modifier = Modifier,
) {
    if (reduce) {
        // 降级：静态单光斑
        Canvas(modifier) {
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(Color(0xFF6FD8FF).copy(alpha = 0.08f), Color.Transparent),
                    center = Offset(size.width * 0.7f, size.height * 0.2f),
                    radius = size.width * 0.6f,
                ),
                radius = size.width * 0.6f,
                center = Offset(size.width * 0.7f, size.height * 0.2f),
            )
        }
        return
    }
    val transition = rememberInfiniteTransition(label = "liquid")
    val t0 by transition.animateFloat(0f, 1f, infiniteRepeatable(tween(8000, easing = LinearEasing)), label = "t0")
    val t1 by transition.animateFloat(0f, 1f, infiniteRepeatable(tween(12500, easing = LinearEasing), RepeatMode.Restart), label = "t1")
    val t2 by transition.animateFloat(0f, 1f, infiniteRepeatable(tween(15000, easing = LinearEasing)), label = "t2")

    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val twoPi = (2.0 * PI).toFloat()
        val touch = touchOffset.value // draw 阶段读取

        fun blob(t: Float, ax: Float, ay: Float, fx: Float, fy: Float, phase: Float): Offset = Offset(
            w / 2f + ax * sin(twoPi * fx * t + phase) + touch.x,
            h / 2f + ay * sin(twoPi * fy * t) + touch.y,
        )

        val blobs = listOf(
            Triple(blob(t0, w * 0.35f, h * 0.30f, 1f, 2f, 0f), w * 0.55f, Color(0xFF6FD8FF).copy(alpha = 0.12f)),
            Triple(blob(t1, w * 0.42f, h * 0.36f, 2f, 1f, 1.5f), w * 0.60f, Color(0xFFB58CFF).copy(alpha = 0.10f)),
            Triple(blob(t2, w * 0.50f, h * 0.42f, 1f, 1f, 3.1f), w * 0.70f, Color(0xFF7DFFC2).copy(alpha = 0.06f)),
        )
        blobs.forEach { (center, radius, color) ->
            drawCircle(
                brush = Brush.radialGradient(listOf(color, Color.Transparent), center = center, radius = radius),
                radius = radius,
                center = center,
                blendMode = BlendMode.Screen,
            )
        }
    }
}

/** 玻璃模糊 RenderEffect 工具（API31+，供骨架屏/弹窗复用） */
fun glassBlurRenderEffect(radiusDp: Float): RenderEffect =
    RenderEffect.createBlurEffect(radiusDp, radiusDp, Shader.TileMode.CLAMP).asComposeRenderEffect()
