package com.shieldguard.app.data.repo

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.shieldguard.app.core.SgLog
import com.shieldguard.app.core.Sha256
import com.shieldguard.app.core.TokenBucket
import com.shieldguard.app.data.api.Stats
import com.shieldguard.app.data.api.VtClient
import com.shieldguard.app.data.db.AppDatabase
import com.shieldguard.app.data.db.ScanResultEntity
import com.shieldguard.app.data.db.ScanTaskEntity
import com.shieldguard.app.data.db.Verdict
import com.shieldguard.app.data.prefs.SettingsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException

/**
 * 扫描仓库：公共扫描流水线（规范 2 卡片 B）：
 * 入队 → SHA-256 → 24h 本地缓存 →（隐私模式？哈希查询：上传文件）→ 轮询分析 → 结果落库。
 */
class ScanRepository(
    private val context: Context,
    private val db: AppDatabase,
    private val vt: VtClient,
    private val settings: SettingsRepository,
) {

    private val cacheTtl = 24 * 60 * 60 * 1000L

    // ---------- 判定 ----------

    fun verdictOf(stats: Stats): Int = when {
        stats.malicious > 0 -> Verdict.MALICIOUS
        stats.suspicious > 0 -> Verdict.SUSPICIOUS
        else -> Verdict.SAFE
    }

    fun vtLinkOf(sha256: String) = "https://www.virustotal.com/gui/file/$sha256"

    // ---------- 目标解析 ----------

    data class ScanTarget(
        val key: String,
        val displayName: String,
        val sizeBytes: Long,
        val isApkFile: Boolean,
        val contentUri: Uri?,   // SAF uri（可选安装）
        val sourceFile: File?,  // 已安装应用的 sourceDir
    )

    suspend fun resolve(key: String): ScanTarget? = withContext(Dispatchers.IO) {
        runCatching {
            if (key.startsWith("uri:")) {
                val uri = Uri.parse(key.removePrefix("uri:"))
                val (name, size) = queryApkMeta(uri)
                ScanTarget(key, name, size, isApkFile = true, contentUri = uri, sourceFile = null)
            } else {
                val pkg = key.removePrefix("pkg:")
                val appInfo = context.packageManager.getApplicationInfo(pkg, 0)
                val source = File(appInfo.sourceDir ?: return@runCatching null)
                ScanTarget(
                    key, context.packageManager.getApplicationLabel(appInfo).toString(),
                    source.length(), isApkFile = false, contentUri = null, sourceFile = source,
                )
            }
        }.getOrNull()
    }

    private fun queryApkMeta(uri: Uri): Pair<String, Long> {
        var name = "未知安装包"
        var size = 0L
        context.contentResolver.query(uri, null, null, null, null)?.use { c ->
            val nameIdx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val sizeIdx = c.getColumnIndex(OpenableColumns.SIZE)
            if (c.moveToFirst()) {
                if (nameIdx >= 0) name = c.getString(nameIdx) ?: name
                if (sizeIdx >= 0) c.getLong(sizeIdx).takeIf { it > 0 }?.let { size = it }
            }
        }
        return name to size
    }

    // ---------- 核心扫描 ----------

    /**
     * 执行一次完整扫描。返回 null 表示任务被跳过（如文件无法读取）。
     * onProgress: 0~1（复制/上传阶段的粗粒度进度）。
     */
    suspend fun scanTarget(
        key: String,
        onProgress: (Float) -> Unit = {},
        onStage: (String) -> Unit = {},
    ): ScanResultEntity? = withContext(Dispatchers.IO) {
        val target = resolve(key) ?: return@withContext null

        // ① SHA-256 + 24h 缓存
        onStage("计算哈希")
        val (sha256, localFile) = prepareSource(target)
            ?: return@withContext null
        db.scanResultDao().byKey(key)?.let { cached ->
            if (cached.sha256 == sha256 && System.currentTimeMillis() - cached.scannedAt < cacheTtl) {
                SgLog.d("ScanRepo", "命中 24h 缓存：${target.displayName}")
                onStage("缓存命中")
                return@withContext cached
            }
        }

        // ② 隐私模式 / 64MB 超限 → 只传哈希
        val privacy = settings.privacyHashOnly.first()
        val stats: Stats = if (privacy || target.sizeBytes > SettingsRepository.MAX_FILE_BYTES) {
            if (!privacy) SgLog.i("ScanRepo", "文件超 64MB，回退哈希查询：${target.displayName}")
            onStage("哈希查询")
            vt.fileReport(sha256)
                // VT 未收录该哈希时主动上传补采（文件在 64MB 内才可行）
                ?: if (target.sizeBytes <= SettingsRepository.MAX_FILE_BYTES && localFile != null) {
                    onStage("VT 未收录，上传补采")
                    uploadAndPoll(localFile, onProgress)
                } else Stats()
        } else {
            val file = localFile ?: return@withContext null
            onStage("上传分析")
            uploadAndPoll(file, onProgress)
        }

        // ③ 结果落库
        val entity = ScanResultEntity(
            targetKey = key,
            displayName = target.displayName,
            sha256 = sha256,
            verdict = verdictOf(stats),
            malicious = stats.malicious,
            suspicious = stats.suspicious,
            harmless = stats.harmless,
            sizeBytes = target.sizeBytes,
            isApkFile = target.isApkFile,
        )
        db.scanResultDao().upsert(entity)
        entity
    }

    private suspend fun uploadAndPoll(file: File, onProgress: (Float) -> Unit): Stats {
        val analysisId = vt.uploadFile(file) { p -> onProgress(p * 0.9f) }
        onProgress(0.92f)
        val stats = vt.waitForAnalysis(analysisId)
        onProgress(1f)
        return stats
    }

    /** 返回 (sha256, 可上传的本地文件；隐私模式/installed app 用系统 APK 路径可直接读) */
    private suspend fun prepareSource(target: ScanTarget): Pair<String, File?>? =
        withContext(Dispatchers.IO) {
            val file: File = when {
                target.sourceFile != null -> target.sourceFile
                target.contentUri != null -> {
                    // SAF uri 不能直接给 OkHttp，复制到 cacheDir 临时文件（同时支撑哈希与上传）
                    val tmp = File(context.cacheDir, "scan_${System.nanoTime()}.apk")
                    context.contentResolver.openInputStream(target.contentUri)?.use { input ->
                        tmp.outputStream().use { output -> input.copyTo(output) }
                    } ?: return@withContext null
                    tmp
                }
                else -> return@withContext null
            }
            Sha256.of(file) to file
        }

    // ---------- 任务队列 ----------

    /** 入队 + 交给 WorkManager（带指数退避重试） */
    suspend fun enqueue(keys: List<String>) {
        val dao = db.scanTaskDao()
        keys.forEach { key ->
            val name = resolve(key)?.displayName ?: key
            val taskId = dao.insert(ScanTaskEntity(targetKey = key, displayName = name))
            com.shieldguard.app.work.ScanWorker.enqueueTask(context, taskId)
        }
    }

    /** 重试单个失败任务 */
    suspend fun retryTask(task: ScanTaskEntity) {
        db.scanTaskDao().update(task.copy(status = ScanTaskEntity.STATUS_QUEUED))
        com.shieldguard.app.work.ScanWorker.enqueueTask(context, task.id)
    }

    /** 重试全部失败任务 */
    suspend fun retryFailed() {
        db.scanTaskDao().failed().forEach { retryTask(it) }
    }

    /** WorkManager 调用的单任务执行入口 */
    suspend fun runTask(taskId: Long): Boolean {
        val task = db.scanTaskDao().byId(taskId) ?: return true
        db.scanTaskDao().update(task.copy(status = ScanTaskEntity.STATUS_RUNNING))
        return try {
            val result = scanTarget(task.targetKey) ?: throw IOException("目标不可读")
            db.scanTaskDao().update(task.copy(status = ScanTaskEntity.STATUS_DONE, attempts = task.attempts + 1))
            result.verdict == Verdict.MALICIOUS // 返回是否报毒，Worker 可用于发告警
        } catch (t: Throwable) {
            SgLog.e("ScanRepo", "任务 ${task.id} 失败：${t.message}")
            db.scanTaskDao().update(task.copy(status = ScanTaskEntity.STATUS_FAILED, attempts = task.attempts + 1))
            false
        }
    }

    companion object {
        fun startOfDay(): Long {
            val cal = java.util.Calendar.getInstance()
            cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
            cal.set(java.util.Calendar.MINUTE, 0)
            cal.set(java.util.Calendar.SECOND, 0)
            cal.set(java.util.Calendar.MILLISECOND, 0)
            return cal.timeInMillis
        }
    }
}
