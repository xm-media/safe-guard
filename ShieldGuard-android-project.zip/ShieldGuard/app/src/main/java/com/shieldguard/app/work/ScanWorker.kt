package com.shieldguard.app.work

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.shieldguard.app.core.ServiceLocator
import com.shieldguard.app.core.SgLog
import com.shieldguard.app.data.db.Verdict
import com.shieldguard.app.service.AlertManager
import java.util.concurrent.TimeUnit

/**
 * 扫描重试队列（规范 1：失败任务落库由 WorkManager 重试）。
 * - 网络约束：CONNECTED；
 * - 指数退避：30s → 60s → 120s…；
 * - 单任务一个 WorkRequest，互不阻塞。
 */
class ScanWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val taskId = inputData.getLong(KEY_TASK_ID, -1L)
        if (taskId < 0) return Result.failure()
        val sl = ServiceLocator
        val malicious = try {
            sl.scanRepository.runTask(taskId)
        } catch (t: Throwable) {
            SgLog.e("ScanWorker", "任务 $taskId 异常：${t.message}")
            null
        }
        return when (malicious) {
            true -> {
                // 队列路径扫出报毒同样要告警 + 日志（与实时防护同一出口）
                val task = sl.db.scanTaskDao().byId(taskId)
                val result = task?.let { sl.db.scanResultDao().byKey(it.targetKey) }
                if (task != null && result != null) {
                    val info = AlertManager.AlertInfo(
                        packageName = result.displayName,
                        installSource = "手动扫描",
                        engineHits = result.malicious,
                        sha256 = result.sha256,
                    )
                    AlertManager.writeLog(applicationContext, info, sl.scanRepository.vtLinkOf(result.sha256))
                    AlertManager.fire(applicationContext, info)
                }
                Result.success()
            }
            false -> Result.success()
            null -> {
                // 失败重试：最多 5 次（runAttemptCount 由 WorkManager 维护）
                if (runAttemptCount < 5) Result.retry() else Result.failure()
            }
        }
    }

    companion object {
        const val KEY_TASK_ID = "task_id"

        /**
         * 入队方法（由 ScanRepository.enqueue 调用）：
         * 每个任务一条请求 + 指数退避 + 网络约束，任务互不阻塞。
         */
        fun enqueueTask(context: Context, taskId: Long) {
            val request = OneTimeWorkRequestBuilder<ScanWorker>()
                .setInputData(workDataOf(KEY_TASK_ID to taskId))
                .setConstraints(
                    Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()
                )
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
                .addTag("scan_task")
                .build()
            WorkManager.getInstance(context).enqueueUniqueWork(
                "scan_task_$taskId", ExistingWorkPolicy.REPLACE, request,
            )
        }
    }
}
