package com.shieldguard.app

import android.app.Application
import androidx.core.app.NotificationManagerCompat
import com.shieldguard.app.core.ServiceLocator
import com.shieldguard.app.service.AlertManager

class ShieldGuardApp : Application() {

    override fun onCreate() {
        super.onCreate()
        ServiceLocator.init(this)
        AlertManager.ensureChannels(this)
    }
}
