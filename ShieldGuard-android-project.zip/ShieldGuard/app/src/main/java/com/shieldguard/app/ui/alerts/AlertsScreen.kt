package com.shieldguard.app.ui.alerts

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.content.Intent
import android.net.Uri
import com.shieldguard.app.core.ServiceLocator
import com.shieldguard.app.data.db.AlertLogEntity
import com.shieldguard.app.ui.components.EmptyState
import com.shieldguard.app.ui.nav.sgSharedElement
import com.shieldguard.app.ui.theme.DangerRed
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** 告警日志页：卡片 A 写入的报毒记录，可跳转 VT 报告 */
@Composable
fun AlertsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val alerts by ServiceLocator.db.alertLogDao().all().collectAsState(initial = emptyList())
    val fmt = remember { SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()) }

    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "返回") }
            Text(
                "告警日志",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.sgSharedElement("alerts.title"),
            )
        }
        if (alerts.isEmpty()) {
            EmptyState("暂无告警\n实时防护发现报毒应用时会记录在这里")
            return@Column
        }
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize(),
        ) {
            items(alerts, key = { it.id }) { alert ->
                AlertRow(alert, fmt) {
                    context.startActivity(
                        Intent(Intent.ACTION_VIEW, Uri.parse(alert.vtUrl)),
                    )
                }
            }
            item { Spacer(Modifier.height(90.dp)) }
        }
    }
}

@Composable
private fun AlertRow(alert: AlertLogEntity, fmt: SimpleDateFormat, onOpenVt: () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(DangerRed.copy(alpha = 0.08f))
            .clickable(onClick = onOpenVt)
            .padding(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(alert.packageName, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.weight(1f))
            Icon(Icons.AutoMirrored.Rounded.OpenInNew, "打开 VT 报告", Modifier.size(16.dp), tint = Color(0xFF8C96B0))
        }
        Text(
            "命中引擎 ${alert.engineHits} 款 · 来源 ${alert.installSource}",
            fontSize = 12.sp, color = Color(0xFF8C96B0),
        )
        Text("检出时间 ${fmt.format(Date(alert.detectedAt))}", fontSize = 11.sp, color = Color(0xFF8C96B0))
    }
}
