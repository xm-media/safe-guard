package com.shieldguard.app.ui.alerts

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.shieldguard.app.data.db.AlertLogEntity
import com.shieldguard.app.ui.components.LocalReduceMotion
import com.shieldguard.app.ui.components.RedShimmerOverlay
import com.shieldguard.app.ui.theme.DangerRed
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 告警弹窗（规范 5.4）：中心膨胀入场 + 局部折射扭曲，
 * scrim alpha 0.5 + blur 8dp，报毒条目红色 shimmer 自上而下扫过 1.2s。
 */
@Composable
fun AlertPopup(alert: AlertLogEntity?, onDismiss: () -> Unit) {
    if (alert == null) return
    val reduce = LocalReduceMotion.current

    // 中心膨胀入场：scale 0.75→1 spring 过冲
    val enter = remember { Animatable(if (reduce) 1f else 0.75f) }
    LaunchedEffect(alert.id) {
        if (!reduce) enter.animateTo(1f, spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMedium))
    }

    Dialog(onDismissRequest = onDismiss) {
        Column(
            Modifier
                .graphicsLayer {
                    scaleX = enter.value
                    scaleY = enter.value
                    alpha = ((enter.value - 0.7f) / 0.3f).coerceIn(0f, 1f)
                }
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0xCC141A2E))
                .drawWithContent {
                    drawContent()
                    // 渐变描边（玻璃质感）
                    drawRoundRect(
                        brush = Brush.linearGradient(
                            listOf(Color.White.copy(0.5f), Color.White.copy(0.08f)),
                            start = Offset.Zero,
                            end = Offset(size.width, size.height),
                        ),
                        style = Stroke(0.75.dp.toPx()),
                    )
                    // "局部折射扭曲"近似：顶部一道细碎折射高光（dash 折线）
                    drawRoundRect(
                        brush = Brush.verticalGradient(
                            listOf(DangerRed.copy(alpha = 0.35f), Color.Transparent),
                            startY = 0f, endY = size.height * 0.3f,
                        ),
                        style = Stroke(
                            1.dp.toPx(),
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 6f)),
                        ),
                    )
                }
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text("🚨 发现恶意应用", color = DangerRed, fontSize = 18.sp)
            Row { Text("应用包名：", color = Color(0xFFB9C2DA), fontSize = 13.sp); Text(alert.packageName, color = Color.White, fontSize = 13.sp) }
            Row { Text("安装来源：", color = Color(0xFFB9C2DA), fontSize = 13.sp); Text(alert.installSource, color = Color.White, fontSize = 13.sp) }
            Row { Text("命中引擎：", color = Color(0xFFB9C2DA), fontSize = 13.sp); Text("${alert.engineHits} 款", color = DangerRed, fontSize = 13.sp) }
            Text(
                "检测时间：" + SimpleDateFormat("MM-dd HH:mm", Locale.getDefault()).format(Date(alert.detectedAt)),
                color = Color(0xFF8C96B0), fontSize = 12.sp,
            )
            // 报毒条目：红色 shimmer 自上而下扫过 1.2s
            androidx.compose.foundation.layout.Box(
                Modifier
                    .fillMaxWidth()
                    .height(34.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(DangerRed.copy(alpha = 0.15f)),
            ) {
                RedShimmerOverlay(Modifier.matchParentSize())
                Text(
                    "该应用已被多款安全引擎判定为恶意软件，建议立即卸载。",
                    color = Color.White, fontSize = 12.sp,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                )
            }
            TextButton(onClick = onDismiss, modifier = Modifier.align(androidx.compose.ui.Alignment.End)) {
                Text("知道了", color = Color(0xFF7DA6FF))
            }
        }
    }
}
