package com.shieldguard.app.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shieldguard.app.data.db.Verdict
import com.shieldguard.app.ui.theme.DangerRed
import com.shieldguard.app.ui.theme.SafeGreen
import com.shieldguard.app.ui.theme.WarnYellow

/** 判定色映射：安全(绿)/可疑(黄)/报毒(红) */
fun verdictColor(verdict: Int): Color = when (verdict) {
    Verdict.SAFE -> SafeGreen
    Verdict.SUSPICIOUS -> WarnYellow
    else -> DangerRed
}

fun verdictLabel(verdict: Int): String = when (verdict) {
    Verdict.SAFE -> "安全"
    Verdict.SUSPICIOUS -> "可疑"
    else -> "报毒"
}

/**
 * 玻璃质感分段控制器（规范 2 卡片 B）。
 * 指示器用 spring 弹到目标位，切换带"液态吸附"手感；选中项做 1.15→1.0 弹性形变。
 */
@Composable
fun SegmentedGlassControl(
    options: List<String>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val reduce = LocalReduceMotion.current
    Box(
        modifier
            .fillMaxWidth()
            .height(42.dp)
            .clip(RoundedCornerShape(21.dp))
            .background(Color.White.copy(alpha = 0.08f))
            .border(0.5.dp, Brush.linearGradient(listOf(Color.White.copy(0.35f), Color.White.copy(0.06f))), RoundedCornerShape(21.dp))
            .padding(3.dp),
    ) {
        // 液态指示器：位置 spring 吸附
        val indicatorWidth = 1f / options.size.coerceAtLeast(1)
        val targetFraction = if (options.isEmpty()) 0f else selectedIndex.toFloat() / options.size
        val fraction by animateFloatAsState(
            targetValue = targetFraction,
            animationSpec = spring(dampingRatio = 0.6f, stiffness = 380f),
            label = "segmentIndicator",
        )
        Box(
            Modifier
                .fillMaxWidth()
                .height(36.dp)
                .graphicsLayer {
                    translationX = size.width * fraction
                    alpha = if (reduce) 1f else 0.95f
                }
                .clip(RoundedCornerShape(18.dp))
                .background(Brush.linearGradient(listOf(Color.White.copy(0.22f), Color.White.copy(0.10f)))),
        )
        Row(Modifier.fillMaxWidth()) {
            options.forEachIndexed { index, label ->
                val scale by animateFloatAsState(
                    targetValue = if (index == selectedIndex) 1f else 0.94f,
                    animationSpec = spring(dampingRatio = 0.4f), // 液滴吸附：过冲回弹
                    label = "segmentScale$index",
                )
                Box(
                    Modifier
                        .weight(indicatorWidth.coerceAtLeast(0.001f))
                        .fillMaxWidth()
                        .height(36.dp)
                        .clickable(indication = null, interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }) { onSelect(index) },
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        label,
                        fontSize = 13.sp,
                        color = if (index == selectedIndex) MaterialTheme.colorScheme.onBackground
                        else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.55f),
                        modifier = Modifier.graphicsLayer {
                            scaleX = scale
                            scaleY = scale
                        },
                    )
                }
            }
        }
    }
}

/** 勾选液滴：选中瞬间 scale 1.15 → 1.0 弹性形变（规范 5.3） */
@Composable
fun DropletCheckbox(checked: Boolean, onCheckedChange: (Boolean) -> Unit, modifier: Modifier = Modifier) {
    val scale = remember { androidx.compose.animation.core.Animatable(1f) }
    androidx.compose.runtime.LaunchedEffect(checked) {
        if (checked) {
            scale.snapTo(1.15f) // 液滴吸附过冲
            scale.animateTo(1f, spring(dampingRatio = 0.35f))
        } else {
            scale.snapTo(1f)
        }
    }
    Box(
        modifier
            .size(24.dp)
            .graphicsLayer { scaleX = scale.value; scaleY = scale.value }
            .clip(RoundedCornerShape(8.dp))
            .background(if (checked) SafeGreen else Color.White.copy(alpha = 0.10f))
            .border(
                1.dp,
                if (checked) SafeGreen else Color.White.copy(alpha = 0.35f),
                RoundedCornerShape(8.dp),
            )
            .clickable(indication = null, interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }) {
                onCheckedChange(!checked)
            },
        contentAlignment = Alignment.Center,
    ) {
        if (checked) {
            Text("✓", color = Color.White, fontSize = 14.sp)
        }
    }
}

/** 玻璃骨架屏 shimmer（加载态，规范 6 三态） */
@Composable
fun GlassSkeleton(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "shimmer")
    val t by transition.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(1100, easing = LinearEasing), RepeatMode.Restart),
        label = "shimmerT",
    )
    Box(modifier.clip(RoundedCornerShape(10.dp)).drawBehindShimmer(t))
}

private fun Modifier.drawBehindShimmer(t: Float): Modifier = this.then(
    Modifier.graphicsLayer { alpha = 0.9f },
).background(
    Brush.linearGradient(
        colors = listOf(
            Color.White.copy(alpha = 0.06f),
            Color.White.copy(alpha = 0.18f),
            Color.White.copy(alpha = 0.06f),
        ),
        start = Offset(-400f + 900f * t, 0f),
        end = Offset(100f + 900f * t, 80f),
    ),
)

/** 空状态 */
@Composable
fun EmptyState(text: String, modifier: Modifier = Modifier) {
    Column(
        modifier.fillMaxWidth().padding(vertical = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text("🛡️", fontSize = 34.sp)
        Text(text, fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.55f))
    }
}

/** 可重试错误态 */
@Composable
fun ErrorState(text: String, onRetry: () -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier.fillMaxWidth().padding(vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text("⚠️ " + text, fontSize = 13.sp, color = WarnYellow)
        GlassPillButton("重试", onClick = onRetry)
    }
}

/** 玻璃胶囊按钮 */
@Composable
fun GlassPillButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    Box(
        modifier
            .clip(RoundedCornerShape(50))
            .background(
                if (enabled) Brush.linearGradient(listOf(Color(0xFF3D7BFF).copy(0.85f), Color(0xFF6FD8FF).copy(0.75f)))
                else Brush.linearGradient(listOf(Color.Gray.copy(0.3f), Color.Gray.copy(0.2f))),
            )
            .clickable(enabled = enabled, indication = null, interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }, onClick = onClick)
            .padding(horizontal = 22.dp, vertical = 9.dp),
    ) {
        Text(text, color = Color.White, fontSize = 13.sp)
    }
}

/** 玻璃主按钮（整行） */
@Composable
fun GlassButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    Box(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(
                if (enabled) Brush.linearGradient(listOf(Color(0xFF3D7BFF).copy(0.9f), Color(0xFF6FD8FF).copy(0.7f)))
                else Brush.linearGradient(listOf(Color.Gray.copy(0.3f), Color.Gray.copy(0.2f))),
            )
            .clickable(enabled = enabled, indication = null, interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }, onClick = onClick)
            .padding(vertical = 12.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = Color.White, fontSize = 14.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
    }
}

/** 玻璃输入框：透明底 + 细描边，与卡片材质统一 */
@Composable
fun GlassTextField(
    value: String,
    onValueChange: (String) -> Unit,
    placeholder: String,
    modifier: Modifier = Modifier,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier.fillMaxWidth(),
        placeholder = { Text(placeholder, fontSize = 13.sp, color = Color(0xFF8C96B0)) },
        singleLine = true,
        shape = RoundedCornerShape(14.dp),
        textStyle = TextStyle(fontSize = 14.sp, color = MaterialTheme.colorScheme.onBackground),
        colors = OutlinedTextFieldDefaults.colors(
            unfocusedContainerColor = Color.White.copy(alpha = 0.06f),
            focusedContainerColor = Color.White.copy(alpha = 0.10f),
            unfocusedBorderColor = Color.White.copy(alpha = 0.20f),
            focusedBorderColor = Color(0xFF3D7BFF).copy(alpha = 0.6f),
        ),
    )
}

/**
 * 报毒条目红色 shimmer：自上而下扫过 1.2s 循环（规范 5.4）。
 * 动画在 draw 阶段读取，不触发 recompose。
 */
@Composable
fun RedShimmerOverlay(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "redShimmer")
    val t by transition.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(1200, easing = LinearEasing), RepeatMode.Restart),
        label = "redT",
    )
    Canvas(modifier) {
        val y = -0.3f + 1.6f * t
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(Color.Transparent, DangerRed.copy(alpha = 0.28f), Color.Transparent),
                startY = size.height * (y - 0.35f),
                endY = size.height * (y + 0.35f),
            ),
        )
    }
}

/**
 * 水波呼吸下划线（规范 5.3 卡片 C）：连通时 underline 水波呼吸，
 * progress ∈ [0,1] 由红转绿扩散（连通瞬间从 0 → 1）。
 */
@Composable
fun WaterWaveUnderline(connected: Boolean, modifier: Modifier = Modifier, progress: Float = 1f) {
    val reduce = LocalReduceMotion.current
    val transition = rememberInfiniteTransition(label = "wave")
    val phase by transition.animateFloat(0f, 1f, infiniteRepeatable(tween(1800, easing = LinearEasing)), label = "wavePhase")
    Canvas(modifier.fillMaxWidth().height(3.dp).clip(RoundedCornerShape(2.dp))) {
        // 红 → 绿 随 progress 渐变（连通瞬间红色警示，随后扩散为绿色）
        val color = lerp(DangerRed, SafeGreen, progress.coerceIn(0f, 1f))
        if (reduce) {
            drawRoundRect(color, cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f))
            return@Canvas
        }
        // 两条正弦波叠加呼吸
        val path = Path()
        val amplitude = (if (connected) size.height * 0.5f else size.height * 0.2f) * (0.4f + 0.6f * progress)
        val waveLength = size.width / 2.2f
        path.moveTo(0f, size.height / 2f)
        var x = 0f
        while (x <= size.width) {
            val y = size.height / 2f + amplitude * kotlin.math.sin((x / waveLength + phase * 2f) * 2f * Math.PI.toFloat())
            path.lineTo(x, y)
            x += 8f
        }
        drawPath(
            path,
            color = color.copy(alpha = if (connected) 0.85f else 0.5f),
            style = Stroke(width = size.height),
        )
    }
}

/** 无涟漪点击（玻璃卡片内文字按钮统一使用，避免 Material 默认波纹破坏玻璃质感） */
@Composable
fun Modifier.clickableNoRipple(onClick: () -> Unit): Modifier {
    val source = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }
    return this.clickable(indication = null, interactionSource = source, onClick = onClick)
}

/** 警告 SnackBar（DNS 回退 / Key 失效等提示） */
@Composable
fun SnackWarn(text: String, onDismiss: () -> Unit, modifier: Modifier = Modifier) {
    Box(modifier.padding(16.dp)) {
        Row(
            Modifier
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0xE6141A2E))
                .border(0.5.dp, Color.White.copy(alpha = 0.2f), RoundedCornerShape(14.dp))
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(text, color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f))
            Text(
                "知道了",
                color = Color(0xFF7DA6FF),
                fontSize = 12.sp,
                modifier = Modifier
                    .padding(start = 10.dp)
                    .clickableNoRipple(onDismiss),
            )
        }
    }
}

/** 判定徽标（安全/可疑/报毒） */
@Composable
fun VerdictChip(verdict: Int, modifier: Modifier = Modifier) {
    Box(
        modifier
            .clip(RoundedCornerShape(50))
            .background(verdictColor(verdict).copy(alpha = 0.18f))
            .padding(horizontal = 10.dp, vertical = 3.dp),
    ) {
        Text(verdictLabel(verdict), color = verdictColor(verdict), fontSize = 11.sp)
    }
}

/**
 * 半透明毛玻璃底部导航（规范 1）：高光随内容滚动位移（视差）。
 * scrollParallax ∈ [0,1] 由页面滚动状态传入。
 */
@Composable
fun GlassBottomBar(
    currentRoute: String,
    scrollParallax: Float,
    onNavigate: (String) -> Unit,
) {
    val reduce = LocalReduceMotion.current
    val parallax = if (reduce) 0f else scrollParallax.coerceIn(0f, 1f)
    Box(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 12.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(Color.White.copy(alpha = 0.10f))
            .drawGlassBar(parallax),
    ) {
        Row(
            Modifier.fillMaxWidth().padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
        ) {
            BarItem("home", "首页", Icons.Rounded.Home, currentRoute == "home", onNavigate)
            BarItem("settings", "设置", Icons.Rounded.Settings, currentRoute == "settings", onNavigate)
        }
    }
}

private fun Modifier.drawGlassBar(parallax: Float): Modifier = androidx.compose.ui.draw.drawWithContent {
    drawContent()
    // 高光光斑随滚动位移（视差）
    drawCircle(
        brush = Brush.radialGradient(
            listOf(Color.White.copy(alpha = 0.16f), Color.Transparent),
            center = Offset(size.width * (0.3f + 0.4f * parallax), -size.height * 0.4f),
            radius = size.width * 0.7f,
        ),
        radius = size.width * 0.7f,
        center = Offset(size.width * (0.3f + 0.4f * parallax), -size.height * 0.4f),
        blendMode = BlendMode.Plus,
    )
    drawRoundRect(
        brush = Brush.linearGradient(
            listOf(Color.White.copy(alpha = 0.4f), Color.White.copy(alpha = 0.06f)),
            start = Offset.Zero, end = Offset(size.width, size.height),
        ),
        style = Stroke(width = 0.75.dp.toPx()),
        cornerRadius = androidx.compose.ui.geometry.CornerRadius(28.dp.toPx()),
    )
}

@Composable
private fun BoxScope.BarItem(
    route: String,
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    onNavigate: (String) -> Unit,
) {
    Column(
        Modifier
            .clickable(indication = null, interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }) { onNavigate(route) }
            .padding(horizontal = 28.dp, vertical = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(
            icon,
            contentDescription = label,
            tint = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
        )
        Text(
            label,
            fontSize = 11.sp,
            color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
        )
    }
}
