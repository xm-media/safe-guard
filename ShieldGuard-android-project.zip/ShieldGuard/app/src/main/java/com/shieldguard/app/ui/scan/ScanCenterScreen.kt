package com.shieldguard.app.ui.scan

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shieldguard.app.core.ServiceLocator
import com.shieldguard.app.data.db.ScanResultEntity
import com.shieldguard.app.data.db.ScanTaskEntity
import com.shieldguard.app.data.db.Verdict
import com.shieldguard.app.ui.components.EmptyState
import com.shieldguard.app.ui.components.GlassSkeleton
import com.shieldguard.app.ui.nav.sgSharedElement
import com.shieldguard.app.ui.theme.DangerRed
import com.shieldguard.app.ui.theme.SafeGreen
import com.shieldguard.app.ui.theme.WarnYellow
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope

/**
 * 扫描中心：任务队列（进行中=骨架屏）+ 结果按 安全/可疑/报毒 三组展示（规范 2 卡片 B）。
 */
@Composable
fun ScanCenterScreen(onBack: () -> Unit) {
    val results by ServiceLocator.db.scanResultDao().all()
        .collectAsState(initial = emptyList())
    val tasks by ServiceLocator.db.scanTaskDao().all()
        .collectAsState(initial = emptyList())
    val scope = rememberCoroutineScope()

    Column(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 20.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, "返回")
            }
            Text(
                "扫描中心",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.sgSharedElement("scan.title"),
            )
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { scope.launch { ServiceLocator.scanRepository.retryFailed() } }) {
                Icon(Icons.Rounded.Refresh, "重试失败任务")
            }
        }

        val running = tasks.filter { it.status == ScanTaskEntity.STATUS_QUEUED || it.status == ScanTaskEntity.STATUS_RUNNING }
        val failed = tasks.filter { it.status == ScanTaskEntity.STATUS_FAILED }
        val grouped = results.groupBy { it.verdict }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize(),
        ) {
            if (running.isNotEmpty()) {
                item { SectionHeader("进行中", Color(0xFF7DA6FF), running.size) }
                items(running, key = { "t${it.id}" }) {
                    GlassSkeleton(Modifier.fillMaxWidth().height(56.dp))
                }
            }
            if (failed.isNotEmpty()) {
                item { SectionHeader("失败（可重试）", WarnYellow, failed.size) }
                items(failed, key = { "f${it.id}" }) { task ->
                    FailedTaskRow(task) { scope.launch { ServiceLocator.scanRepository.retryTask(task) } }
                }
            }
            listOf(
                Triple(Verdict.MALICIOUS, "报毒", DangerRed),
                Triple(Verdict.SUSPICIOUS, "可疑", WarnYellow),
                Triple(Verdict.SAFE, "安全", SafeGreen),
            ).forEach { (verdict, label, color) ->
                val list = grouped[verdict].orEmpty()
                if (list.isNotEmpty()) {
                    item { SectionHeader(label, color, list.size) }
                    items(list, key = { "r${it.targetKey}" }) { result ->
                        ResultRow(result)
                    }
                }
            }
            if (running.isEmpty() && failed.isEmpty() && results.isEmpty()) {
                item {
                    EmptyState("暂无扫描结果\n回到首页勾选应用或选择安装包开始扫描")
                }
            }
            item { Spacer(Modifier.height(90.dp)) }
        }
    }
}

@Composable
private fun SectionHeader(label: String, color: Color, count: Int) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(10.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(8.dp))
        Text("$label · $count", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = color)
    }
}

@Composable
private fun ResultRow(result: ScanResultEntity) {
    val color = when (result.verdict) {
        Verdict.MALICIOUS -> DangerRed
        Verdict.SUSPICIOUS -> WarnYellow
        else -> SafeGreen
    }
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White.copy(alpha = 0.05f))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(38.dp).clip(CircleShape).background(color.copy(alpha = 0.15f))) {
            Text(
                when (result.verdict) {
                    Verdict.MALICIOUS -> "✕"
                    Verdict.SUSPICIOUS -> "!"
                    else -> "✓"
                },
                color = color, fontSize = 16.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.Center),
            )
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(result.displayName, fontSize = 14.sp, maxLines = 1)
            Text(
                "SHA-256 ${result.sha256.take(12)}… · ${result.malicious} 恶意 / ${result.suspicious} 可疑",
                fontSize = 11.sp, color = Color(0xFF8C96B0),
            )
        }
    }
}

@Composable
private fun FailedTaskRow(task: ScanTaskEntity, onRetry: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White.copy(alpha = 0.05f))
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Text(task.displayName, fontSize = 14.sp)
            Text("已尝试 ${task.attempts} 次（指数退避）", fontSize = 11.sp, color = Color(0xFF8C96B0))
        }
        TextButton(onClick = onRetry) { Text("重试", color = MaterialTheme.colorScheme.primary) }
    }
}
