package com.shieldguard.app.data.prefs

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStoreFile
import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import com.shieldguard.app.core.CryptoManager
import com.shieldguard.app.core.SgLog
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

/** 扫描排序方式 */
enum class SortMode { INSTALL_TIME, SIZE }

/**
 * 设置仓库（DataStore Preferences）。
 * 所有开关/配置集中于此，UI 与 Service 均通过 Flow 订阅，保证"状态持久化"。
 */
class SettingsRepository(private val context: Context) {

    private val dataStore = PreferenceDataStoreFactory.create {
        context.preferencesDataStoreFile("settings")
    }

    private object Keys {
        val REALTIME_ENABLED = booleanPreferencesKey("realtime_enabled")
        val SCAN_ENABLED = booleanPreferencesKey("scan_enabled")
        val IGNORE_SYSTEM_APPS = booleanPreferencesKey("ignore_system_apps")
        val USE_CUSTOM_KEY = booleanPreferencesKey("use_custom_key")
        val CUSTOM_KEY_ENC = stringPreferencesKey("custom_key_enc") // AES+Keystore 密文，绝不存明文
        val PUBLIC_KEY_INDEX = intPreferencesKey("public_key_index")
        val PRIVACY_HASH_ONLY = booleanPreferencesKey("privacy_hash_only")
        val REDUCE_MOTION = booleanPreferencesKey("reduce_motion")
        val DNS_SERVER = stringPreferencesKey("dns_server")
        val VPN_ENABLED = booleanPreferencesKey("vpn_enabled")
    }

    companion object {
        /** 公益节点 Key 界面展示值。限速且可能失效，建议用户在设置页替换为自己的 Key */
        const val PUBLIC_KEY_DISPLAY =
            "1243b4856408ce1976ff87365351b84fa98c4ef0eca83c33de36d04b5b7b3e81"

        /** 公益 Key 池：401 时按序切换。当前公益源仅提供一枚，池结构留好扩展位 */
        val PUBLIC_KEYS = listOf(PUBLIC_KEY_DISPLAY)
        const val DEFAULT_DNS = "52.80.60.30"
        const val MAX_FILE_BYTES = 64L * 1024 * 1024 // 单文件上传上限 64MB
    }

    // ---------- 开关类 ----------
    val realtimeEnabled: Flow<Boolean> = dataStore.data.map { it[Keys.REALTIME_ENABLED] ?: false }
    val scanEnabled: Flow<Boolean> = dataStore.data.map { it[Keys.SCAN_ENABLED] ?: true }
    val ignoreSystemApps: Flow<Boolean> = dataStore.data.map { it[Keys.IGNORE_SYSTEM_APPS] ?: true }
    val privacyHashOnly: Flow<Boolean> = dataStore.data.map { it[Keys.PRIVACY_HASH_ONLY] ?: false }
    val reduceMotion: Flow<Boolean> = dataStore.data.map { it[Keys.REDUCE_MOTION] ?: false }
    val vpnEnabled: Flow<Boolean> = dataStore.data.map { it[Keys.VPN_ENABLED] ?: false }
    val dnsServer: Flow<String> = dataStore.data.map { it[Keys.DNS_SERVER] ?: DEFAULT_DNS }

    // ---------- API 配置 ----------
    val useCustomKey: Flow<Boolean> = dataStore.data.map { it[Keys.USE_CUSTOM_KEY] ?: false }

    /** Key 失效事件：UI 收到后弹出"请更换 Key"提示 */
    val keyErrorEvent = kotlinx.coroutines.flow.MutableStateFlow<String?>(null)

    val customKeyMasked: Flow<String?> = dataStore.data.map { prefs ->
        prefs[Keys.CUSTOM_KEY_ENC]?.let { enc ->
            CryptoManager.decrypt(enc)?.let { plain -> plain.take(6) + "****" + plain.takeLast(4) }
        }
    }

    suspend fun setRealtimeEnabled(v: Boolean) = dataStore.edit { it[Keys.REALTIME_ENABLED] = v }
    suspend fun setScanEnabled(v: Boolean) = dataStore.edit { it[Keys.SCAN_ENABLED] = v }
    suspend fun setIgnoreSystemApps(v: Boolean) = dataStore.edit { it[Keys.IGNORE_SYSTEM_APPS] = v }
    suspend fun setPrivacyHashOnly(v: Boolean) = dataStore.edit { it[Keys.PRIVACY_HASH_ONLY] = v }
    suspend fun setReduceMotion(v: Boolean) = dataStore.edit { it[Keys.REDUCE_MOTION] = v }
    suspend fun setVpnEnabled(v: Boolean) = dataStore.edit { it[Keys.VPN_ENABLED] = v }
    suspend fun setDnsServer(v: String) = dataStore.edit { it[Keys.DNS_SERVER] = v.trim() }

    suspend fun setUseCustomKey(v: Boolean) = dataStore.edit { it[Keys.USE_CUSTOM_KEY] = v }

    /** 自定义 Key 经 AES+Keystore 加密后落库 */
    suspend fun saveCustomKey(plainKey: String) = dataStore.edit {
        it[Keys.CUSTOM_KEY_ENC] = CryptoManager.encrypt(plainKey.trim())
        it[Keys.USE_CUSTOM_KEY] = true
    }

    suspend fun clearCustomKey() = dataStore.edit {
        it.remove(Keys.CUSTOM_KEY_ENC)
        it[Keys.USE_CUSTOM_KEY] = false
    }

    /**
     * 取当前生效 Key（网络层同步调用，读缓存级延迟）。
     * 公益 Key 401 时 index 自动后移；自定义 Key 失效则回退公益并抛出事件。
     */
    suspend fun currentApiKey(): String {
        val prefs = dataStore.data.first()
        val useCustom = prefs[Keys.USE_CUSTOM_KEY] ?: false
        if (useCustom) {
            CryptoManager.decrypt(prefs[Keys.CUSTOM_KEY_ENC] ?: "")?.let { return it }
            SgLog.w("Settings", "自定义 Key 解密失败，回退公益 Key")
            keyErrorEvent.value = "自定义 Key 已失效，已回退公益节点，请重新配置"
        }
        val idx = (prefs[Keys.PUBLIC_KEY_INDEX] ?: 0).coerceIn(0, PUBLIC_KEYS.lastIndex)
        return PUBLIC_KEYS[idx]
    }

    /** 收到 401 时由网络层调用：公益 Key 轮换到下一枚，自定义 Key 直接禁用 */
    suspend fun onUnauthorized() {
        val prefs = dataStore.data.first()
        if (prefs[Keys.USE_CUSTOM_KEY] == true) {
            keyErrorEvent.value = "自定义 Key 校验失败（401），已停用，请检查或更换"
            clearCustomKey()
        } else {
            dataStore.edit {
                val cur = it[Keys.PUBLIC_KEY_INDEX] ?: 0
                it[Keys.PUBLIC_KEY_INDEX] = (cur + 1) % PUBLIC_KEYS.size
            }
            keyErrorEvent.value = "公益 Key 已失效（401），请到设置页配置自己的 VirusTotal Key"
        }
    }
}
