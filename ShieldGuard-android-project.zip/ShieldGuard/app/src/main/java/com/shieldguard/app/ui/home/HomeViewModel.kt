package com.shieldguard.app.ui.home

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.VpnService
import android.provider.Settings
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.shieldguard.app.core.ServiceLocator
import com.shieldguard.app.core.SgLog
import com.shieldguard.app.data.db.AlertLogEntity
import com.shieldguard.app.data.db.PickedApkEntity
import com.shieldguard.app.data.db.ScanResultEntity
import com.shieldguard.app.data.db.Verdict
import com.shieldguard.app.data.prefs.SortMode
import com.shieldguard.app.data.repo.ScanRepository
import com.shieldguard.app.service.DnsProber
import com.shieldguard.app.service.DnsVpnService
import com.shieldguard.app.service.ProtectionService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** 已安装应用条目（卡片 B） */
data class AppEntry(
    val packageName: String,
    val label: String,
    val sizeBytes: Long,
    val installTime: Long,
    val isSystem: Boolean,
    val icon: Bitmap?,
    val sourceDir: String,
)

class HomeViewModel : ViewModel() {

    private val sl = ServiceLocator
    private val appContext: Context = sl.appContext

    // ---------- 设置开关（持久化） ----------
    val realtimeEnabled = sl.settings.realtimeEnabled
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
    val scanEnabled = sl.settings.scanEnabled
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)
    val ignoreSystemApps = sl.settings.ignoreSystemApps
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)
    val privacyMode = sl.settings.privacyHashOnly
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
    val dnsServer = sl.settings.dnsServer
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "52.80.60.30")

    // ---------- 实时防护 ----------
    val protectionRunning = ProtectionService.running
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
    val monitorSince = ProtectionService.startedAt
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    /** 今日扫描数（今日已落库的扫描结果数） */
    val todayScanCount: StateFlow<Int> = flow {
        while (true) {
            emit(sl.db.scanResultDao().countSince(ScanRepository.startOfDay()))
            kotlinx.coroutines.delay(5000)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // ---------- 网页防护 ----------
    private val vpnState = DnsVpnService.state
    val vpnRunning = kotlinx.coroutines.flow.map(vpnState) { it.connected }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
    val vpnSince = kotlinx.coroutines.flow.map(vpnState) { it.connectedAt }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)
    val vpnDns = kotlinx.coroutines.flow.map(vpnState) { it.dnsServer }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "")
    val vpnBlocked = kotlinx.coroutines.flow.map(vpnState) { it.blockedCount }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    private val _vpnWarning = MutableStateFlow<String?>(null)
    val vpnWarning = _vpnWarning.asStateFlow()

    /** 待用户确认的 VPN 授权意图（VpnService.prepare 返回非空时发出） */
    private val _vpnPrepareIntent = MutableStateFlow<Intent?>(null)
    val vpnPrepareIntent = _vpnPrepareIntent.asStateFlow()

    // ---------- 应用列表 ----------
    private val _apps = MutableStateFlow<List<AppEntry>>(emptyList())
    private val _appsLoading = MutableStateFlow(false)
    val appsLoading = _appsLoading.asStateFlow()
    val query = MutableStateFlow("")
    val sortMode = MutableStateFlow(SortMode.INSTALL_TIME)

    val visibleApps: StateFlow<List<AppEntry>> = combine(
        _apps, query, sortMode, ignoreSystemApps,
    ) { apps, q, sort, ignoreSys ->
        apps
            .filter { !ignoreSys || !it.isSystem }
            .filter { it.label.contains(q, true) || it.packageName.contains(q, true) }
            .sortedWith(
                if (sort == SortMode.INSTALL_TIME) compareByDescending { it.installTime }
                else compareByDescending { it.sizeBytes }
            )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val selected = MutableStateFlow<Set<String>>(emptySet())

    // ---------- 扫描数据 ----------
    val scanResults = sl.db.scanResultDao().all()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val pickedApks = sl.db.pickedApkDao().all()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // ---------- 告警弹窗 ----------
    private val _popupAlert = MutableStateFlow<AlertLogEntity?>(null)
    val popupAlert = _popupAlert.asStateFlow()

    init {
        // 前台出现新告警 → 弹出告警弹窗（规范 5.4）
        viewModelScope.launch {
            sl.db.alertLogDao().all().collect { logs ->
                val latest = logs.firstOrNull { !it.seen } ?: return@collect
                if (_popupAlert.value == null) _popupAlert.value = latest
            }
        }
    }

    fun dismissAlert(alert: AlertLogEntity) {
        _popupAlert.value = null
        viewModelScope.launch { sl.db.alertLogDao().markSeen(alert.id) }
    }

    // ---------- 卡片 A：实时防护 ----------
    fun setRealtime(on: Boolean) {
        viewModelScope.launch { sl.settings.setRealtimeEnabled(on) }
        if (on) {
            // 前台服务从系统 12+ 需要应用在前台启动，此处均由用户点击触发，满足约束
            ProtectionService.start(appContext)
        } else {
            ProtectionService.stop(appContext)
        }
    }

    // ---------- 卡片 B：扫描 ----------
    fun loadAppsIfNeeded() {
        if (_appsLoading.value || _apps.value.isNotEmpty()) return
        _appsLoading.value = true
        viewModelScope.launch(Dispatchers.IO) {
            val pm = appContext.packageManager
            val list = pm.getInstalledPackages(0).mapNotNull { info ->
                val appInfo = info.applicationInfo ?: return@mapNotNull null
                val isSystem = (appInfo.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0
                val label = try { pm.getApplicationLabel(appInfo).toString() } catch (_: Exception) { info.packageName }
                AppEntry(
                    packageName = info.packageName,
                    label = label,
                    sizeBytes = try { java.io.File(appInfo.sourceDir ?: "").length() } catch (_: Exception) { 0L },
                    installTime = info.firstInstallTime,
                    isSystem = isSystem,
                    // 图标一次性转 Bitmap，避免列表滚动时反复 inflate Drawable
                    icon = try { appInfo.loadIcon(pm).toBitmap(96, 96) } catch (_: Exception) { null },
                    sourceDir = appInfo.sourceDir ?: "",
                )
            }
            _apps.value = list
            _appsLoading.value = false
        }
    }

    fun setQuery(q: String) { query.value = q }
    fun setSortMode(m: SortMode) { sortMode.value = m }
    fun setIgnoreSystem(on: Boolean) { viewModelScope.launch { sl.settings.setIgnoreSystemApps(on) } }
    fun setScanEnabled(on: Boolean) { viewModelScope.launch { sl.settings.setScanEnabled(on) } }

    fun toggleSelect(packageName: String) {
        selected.value = selected.value.toMutableSet().apply {
            if (!add(packageName)) remove(packageName)
        }
    }

    /** 处理 SAF 多选结果：持久化读权限 → 查询元数据 → 落库 */
    fun addPickedUris(uris: List<android.net.Uri>) {
        viewModelScope.launch(Dispatchers.IO) {
            val resolver = appContext.contentResolver
            val entities = uris.mapNotNull { uri ->
                try {
                    // takePersistableUriPermission 保证进程重启后仍能读取（规范 2 卡片 B）
                    resolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION,
                    )
                    var name = uri.lastPathSegment ?: "unknown.apk"
                    var size = 0L
                    resolver.query(uri, null, null, null, null)?.use { cursor ->
                        val nameIdx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                        val sizeIdx = cursor.getColumnIndex(android.provider.OpenableColumns.SIZE)
                        if (cursor.moveToFirst()) {
                            if (nameIdx >= 0) name = cursor.getString(nameIdx) ?: name
                            if (sizeIdx >= 0 && !cursor.isNull(sizeIdx)) size = cursor.getLong(sizeIdx)
                        }
                    }
                    PickedApkEntity(
                        uriString = uri.toString(),
                        displayName = name,
                        sizeBytes = size,
                        sourceHint = "文档 " + (uri.authority ?: "SAF"),
                    )
                } catch (t: Throwable) {
                    SgLog.e("HomeVM", "持久化 URI 失败：${t.message}")
                    null
                }
            }
            sl.db.pickedApkDao().insertAll(entities)
        }
    }

    fun removePicked(uriString: String) {
        viewModelScope.launch { sl.db.pickedApkDao().delete(uriString) }
    }

    /** 开始扫描：选中的已装应用 + 所有已选安装包 */
    fun startScan() {
        val keys = buildList {
            selected.value.forEach { add("pkg:$it") }
            pickedApks.value.forEach { add("uri:${it.uriString}") }
        }
        if (keys.isEmpty()) return
        viewModelScope.launch { sl.scanRepository.enqueue(keys) }
        selected.value = emptySet()
    }

    // ---------- 卡片 C：网页防护 ----------
    fun toggleVpn(on: Boolean) {
        viewModelScope.launch {
            if (!on) {
                DnsVpnService.stop(appContext)
                return@launch
            }
            // 启用前 UDP 53 探测可达性，超时回退默认 DNS 并警告
            var dns = sl.settings.dnsServer.first()
            val reachable = withContext(Dispatchers.IO) { DnsProber.probe(dns) }
            if (!reachable) {
                dns = "52.80.60.30"
                sl.settings.setDnsServer(dns)
                _vpnWarning.value = "当前 DNS（UDP 53）探测超时，已回退默认 52.80.60.30"
            }
            val prepare = VpnService.prepare(appContext)
            if (prepare != null) {
                _vpnPrepareIntent.value = prepare // 等用户在系统对话框里授权
            } else {
                DnsVpnService.start(appContext)
            }
        }
    }

    fun onVpnPermissionResult(granted: Boolean) {
        _vpnPrepareIntent.value = null
        if (granted) DnsVpnService.start(appContext)
        else _vpnWarning.value = "未授予 VPN 权限，网页防护无法开启"
    }

    fun consumeVpnWarning() { _vpnWarning.value = null }
}
