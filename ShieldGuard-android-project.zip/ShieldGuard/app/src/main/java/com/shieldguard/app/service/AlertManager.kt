package com.shieldguard.app.service

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.PixelFormat
import android.os.Build
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.shieldguard.app.MainActivity
import com.shieldguard.app.R
import com.shieldguard.app.core.SgLog
import com.shieldguard.app.data.db.AlertLogEntity
import kotlinx.coroutines.launch

/**
 * 告警出口：报毒时优先用悬浮窗（已授权 SYSTEM_ALERT_WINDOW），
 * 否则发高优先级通知。同时把告警写入 Room 日志。
 */
object AlertManager {

    const val CHANNEL_PROTECTION = "protection"
    const val CHANNEL_ALERTS = "alerts"
    const val CHANNEL_VPN = "vpn"

    fun ensureChannels(context: Context) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_PROTECTION, context.getString(R.string.protection_channel), NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ALERTS, context.getString(R.string.alert_channel), NotificationManager.IMPORTANCE_HIGH)
        )
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_VPN, context.getString(R.string.vpn_channel), NotificationManager.IMPORTANCE_LOW)
        )
    }

    /** 常驻保护通知：显示监控时长 + 今日扫描数（卡片 A 规格） */
    fun protectionNotification(context: Context, monitorText: String, todayScans: Int): Notification {
        val open = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(context, CHANNEL_PROTECTION)
            .setSmallIcon(R.drawable.ic_notification_shield)
            .setContentTitle("实时防护运行中")
            .setContentText("已监控 $monitorText · 今日扫描 $todayScans 次")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .build()
    }

    data class AlertInfo(
        val packageName: String,
        val installSource: String,
        val engineHits: Int,
        val sha256: String,
    )

    /** 报毒告警：授权悬浮窗则弹悬浮窗，否则高优先级通知；返回 true 表示已通知 */
    fun fire(context: Context, info: AlertInfo): Boolean {
        val vtUrl = "https://www.virustotal.com/gui/file/${info.sha256}"
        if (Settings.canDrawOverlays(context)) {
            showOverlay(context, info)
            return true
        }
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED && Build.VERSION.SDK_INT >= 33
        ) return false

        val open = PendingIntent.getActivity(
            context, 1,
            Intent(Intent.ACTION_VIEW, android.net.Uri.parse(vtUrl)),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(
            (System.currentTimeMillis() and 0x7FFFFFFF).toInt(),
            NotificationCompat.Builder(context, CHANNEL_ALERTS)
                .setSmallIcon(R.drawable.ic_notification_shield)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setContentTitle("⚠ 发现恶意应用")
                .setStyle(
                    NotificationCompat.BigTextStyle()
                        .bigText("包名：${info.packageName}\n安装来源：${info.installSource}\n命中引擎：${info.engineHits} 款\n点击查看 VirusTotal 报告")
                )
                .setContentIntent(open)
                .setAutoCancel(true)
                .build()
        )
        return true
    }

    /**
     * 悬浮窗告警（为什么不用 Dialog：Service 无界面上下文，WindowManager 是唯一出路；
     * 6 秒后自动移除，TYPE_APPLICATION_OVERLAY 是 API 26+ 唯一合法悬浮窗类型）
     */
    private fun showOverlay(context: Context, info: AlertInfo) {
        try {
            val wm = context.getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager
            val view = TextView(context).apply {
                text = "⚠ 发现恶意应用\n${info.packageName}\n来源：${info.installSource} · 命中 ${info.engineHits} 款引擎"
                textSize = 15f
                setTextColor(0xFFFFFFFF.toInt())
                setPadding(40, 32, 40, 32)
                background = android.graphics.drawable.GradientDrawable().apply {
                    cornerRadius = 28f
                    setColor(0xE6C62828.toInt())
                }
            }
            val params = android.view.WindowManager.LayoutParams(
                android.view.WindowManager.LayoutParams.MATCH_PARENT,
                android.view.WindowManager.LayoutParams.WRAP_CONTENT,
                android.view.WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT,
            ).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                y = 160
            }
            wm.addView(view, params)
            view.postDelayed({ runCatching { wm.removeView(view) } }, 6000)
        } catch (t: Throwable) {
            SgLog.e("AlertManager", "悬浮窗展示失败，降级通知", t)
            fire(context, info.copy()) // 悬浮窗失败时二次 fire 会走通知分支（canDrawOverlays 可能仍为 true，防御性处理）
        }
    }

    fun writeLog(context: Context, info: AlertInfo, vtUrl: String) {
        com.shieldguard.app.core.ServiceLocator.applicationScope.launch {
            com.shieldguard.app.core.ServiceLocator.db.alertLogDao().insert(
                AlertLogEntity(
                    packageName = info.packageName,
                    installSource = info.installSource,
                    engineHits = info.engineHits,
                    sha256 = info.sha256,
                    vtUrl = vtUrl,
                )
            )
        }
    }
}
