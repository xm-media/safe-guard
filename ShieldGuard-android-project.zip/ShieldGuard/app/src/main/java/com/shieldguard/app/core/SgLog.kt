package com.shieldguard.app.core

import android.util.Log
import com.shieldguard.app.BuildConfig

/**
 * Release 禁用日志（规范 6：敏感数据不落明文日志）。
 * Debug 全量输出，Release 只保留 error 且不打印消息体以外的参数细节。
 */
object SgLog {
    fun d(tag: String, msg: String) { if (BuildConfig.DEBUG) Log.d(tag, msg) }
    fun i(tag: String, msg: String) { if (BuildConfig.DEBUG) Log.i(tag, msg) }
    fun w(tag: String, msg: String, t: Throwable? = null) { if (BuildConfig.DEBUG) Log.w(tag, msg, t) }
    fun e(tag: String, msg: String, t: Throwable? = null) {
        if (BuildConfig.DEBUG) Log.e(tag, msg, t)
        else Log.e(tag, msg.substring(0, msg.length.coerceAtMost(120)))
    }
}
