package com.shieldguard.app.ui.home

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.GppGood
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.TravelExplore
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.shieldguard.app.core.ServiceLocator
import com.shieldguard.app.data.db.Verdict
import com.shieldguard.app.data.prefs.SortMode
import com.shieldguard.app.service.DnsVpnService
import com.shieldguard.app.service.ProtectionService
import com.shieldguard.app.ui.alerts.AlertPopup
import com.shieldguard.app.ui.components.GlassCard
import com.shieldguard.app.ui.components.SegmentedGlassControl
import com.shieldguard.app.ui.components.SnackWarn
import com.shieldguard.app.ui.components.VerdictChip
import com.shieldguard.app.ui.components.WaterWaveUnderline
import com.shieldguard.app.ui.nav.sgSharedElement
import kotlinx.coroutines.flow.distinctUntilChanged

/** 首页：三张独立开关的玻璃卡片（规范 2） */
@Composable
fun HomeScreen(
    onOpenScanCenter: () -> Unit,
    onOpenAlerts: () -> Unit,
    vm: HomeViewModel = viewModel(),
) {
    val context = LocalContext.current

    // ---- 开关状态订阅 ----
    val realtimeOn by vm.realtimeEnabled.collectAsState()
    val protectionRunning by vm.protectionRunning.collectAsState()
    val monitorSince by vm.monitorSince.collectAsState()
    val todayScans by vm.todayScanCount.collectAsState()
    val scanOn by vm.scanEnabled.collectAsState()
    val vpnOn by vm.vpnRunning.collectAsState()
    val vpnSince by vm.vpnSince.collectAsState()
    val dns by vm.dnsServer.collectAsState()
    val vpnWarning by vm.vpnWarning.collectAsState()
    val popupAlert by vm.popupAlert.collectAsState()

    // ---- 通知权限（API33+）：开启实时防护前请求；拒绝不阻断服务，仅提示 ----
    val notifPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { vm.setRealtime(true) }

    // ---- VPN 授权 ----
    val vpnLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult(),
    ) { result -> vm.onVpnPermissionResult(result.resultCode == android.app.Activity.RESULT_OK) }
    LaunchedEffect(Unit) {
        vm.vpnPrepareIntent.collect { intent -> if (intent != null) vpnLauncher.launch(intent) }
    }

    // ---- SAF 多选安装包 ----
    val apkPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments(),
    ) { uris -> if (uris.isNotEmpty()) vm.addPickedUris(uris) }

    val listState = rememberLazyListState()

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp, 12.dp, 16.dp, 24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            item { HomeHeader() }
            item {
                // 卡片 A｜实时防护
                GlassCard(glowing = realtimeOn && protectionRunning, pulseKey = realtimeOn) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Rounded.GppGood,
                            contentDescription = null,
                            tint = if (realtimeOn) Color(0xFF34C77B) else MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f),
                        )
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                "实时防护",
                                style = MaterialTheme.typography.titleMedium,
                                modifier = Modifier.sgSharedElement("card-protection"),
                            )
                            Text(
                                if (realtimeOn && protectionRunning) "守护中 · 新装应用自动送检" else "已关闭",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                            )
                        }
                        Switch(
                            checked = realtimeOn,
                            onCheckedChange = { on ->
                                if (on && Build.VERSION.SDK_INT >= 33 &&
                                    ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
                                    != PackageManager.PERMISSION_GRANTED
                                ) {
                                    notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
                                } else {
                                    vm.setRealtime(on)
                                }
                            },
                        )
                    }
                    AnimatedVisibility(realtimeOn && protectionRunning) {
                        Row(Modifier.padding(top = 12.dp)) {
                            StatCell("监控时长", formatDuration(System.currentTimeMillis() - monitorSince), Modifier.weight(1f))
                            StatCell("今日扫描", "$todayScans 次", Modifier.weight(1f))
                        }
                    }
                    Text(
                        "查看告警日志 →",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier
                            .padding(top = 10.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .clickableNoRipple(onOpenAlerts),
                    )
                }
            }
            item {
                // 卡片 B｜扫描应用
                GlassCard(pulseKey = scanOn) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Security, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                "扫描应用",
                                style = MaterialTheme.typography.titleMedium,
                                modifier = Modifier.sgSharedElement("card-scan"),
                            )
                            Text(
                                if (scanOn) "本地缓存 24h · SHA-256 去重" else "已关闭",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                            )
                        }
                        Switch(checked = scanOn, onCheckedChange = { vm.setScanEnabled(it) })
                    }
                    AnimatedVisibility(scanOn) {
                        ScanCardBody(vm, apkPicker, onOpenScanCenter = onOpenScanCenter)
                    }
                }
            }
            item {
                // 卡片 C｜网页防护
                val vpnPulse = remember { androidx.compose.animation.core.Animatable(0f) }
                LaunchedEffect(vpnOn) {
                    if (vpnOn) { // 连通：由红转绿的水波扩散（规范 5.3）
                        vpnPulse.snapTo(0f)
                        vpnPulse.animateTo(1f, androidx.compose.animation.core.tween(800))
                    } else {
                        vpnPulse.snapTo(0f)
                    }
                }
                GlassCard(glowing = vpnOn, glowColor = Color(0xFF6FD8FF), pulseKey = vpnOn) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.TravelExplore, contentDescription = null, tint = Color(0xFF6FD8FF))
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                "网页防护",
                                style = MaterialTheme.typography.titleMedium,
                                modifier = Modifier.sgSharedElement("card-web"),
                            )
                            // 连通状态 + underline 水波呼吸
                            WaterWaveUnderline(
                                connected = vpnOn,
                                modifier = Modifier.width(120.dp),
                                progress = vpnPulse.value,
                            )
                        }
                        Switch(checked = vpnOn, onCheckedChange = { vm.toggleVpn(it) })
                    }
                    AnimatedVisibility(vpnOn) {
                        Column(Modifier.padding(top = 12.dp)) {
                            Row {
                                StatCell("会话时长", formatDuration(System.currentTimeMillis() - vpnSince), Modifier.weight(1f))
                                StatCell("当前 DNS", dns, Modifier.weight(1f))
                            }
                            Text(
                                "拦截计数：0（占位）",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                                modifier = Modifier.padding(top = 6.dp),
                            )
                        }
                    }
                }
            }
        }

        // VPN 警告 SnackBar
        vpnWarning?.let { warn ->
            SnackWarn(text = warn, onDismiss = { vm.consumeVpnWarning() }, Modifier.align(Alignment.BottomCenter))
        }

        // 告警弹窗（中心膨胀 + 折射闪烁 + 红 shimmer）
        popupAlert?.let { alert ->
            AlertPopup(
                alert = alert,
                onDismiss = { vm.dismissAlert(alert) },
            )
        }
    }

    // 滚动视差：首页列表滚动 → 底部导航高光位移（规范 1）
    LaunchedEffect(listState) {
        snapshotFlow { listState.firstVisibleItemScrollOffset }
            .distinctUntilChanged()
            .collect { offset ->
                com.shieldguard.app.ui.nav.HomeScrollParallaxStore.parallax =
                    (offset / 40f).coerceIn(0f, 1f)
            }
    }
    // 进入页面时预载已安装应用
    LaunchedEffect(Unit) { vm.loadAppsIfNeeded() }
}

@Composable
private fun HomeHeader() {
    Column {
        Text("安全护盾", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onBackground)
        Text(
            "ShieldGuard · 你的应用安全哨兵",
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
        )
    }
}

@Composable
fun StatCell(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier) {
        Text(label, fontSize = 11.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.55f))
        Text(value, fontSize = 15.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
    }
}

/** 时长格式化 */
fun formatDuration(millis: Long): String {
    if (millis <= 0) return "0 秒"
    val s = millis / 1000
    val h = s / 3600
    val m = (s % 3600) / 60
    return when {
        h > 0 -> "${h} 时 ${m} 分"
        m > 0 -> "${m} 分 ${s % 60} 秒"
        else -> "${s} 秒"
    }
}
