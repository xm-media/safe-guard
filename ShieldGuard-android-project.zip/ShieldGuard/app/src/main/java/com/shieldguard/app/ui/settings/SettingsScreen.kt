package com.shieldguard.app.ui.settings

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Api
import androidx.compose.material.icons.rounded.Dns
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.shieldguard.app.ui.components.GlassCard
import com.shieldguard.app.ui.components.GlassButton
import com.shieldguard.app.ui.components.GlassTextField
import com.shieldguard.app.ui.nav.sgSharedElement
import com.shieldguard.app.ui.theme.DangerRed
import com.shieldguard.app.ui.theme.ShieldAmber

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val vm: SettingsViewModel = viewModel()

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "返回") }
            Text(
                "设置",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.sgSharedElement("settings.title"),
            )
        }
        Spacer(Modifier.height(8.dp))

        // ---- API 配置（二选一） ----
        GlassCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Api, null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(10.dp))
                Text("API 配置", fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(6.dp))
            Text(
                "公益节点，限速且可能失效，建议替换为自己的 Key。",
                fontSize = 12.sp,
                color = ShieldAmber,
            )
            val useCustom by vm.useCustomKey.collectAsState()
            val busy by vm.busy.collectAsState()
            val validation by vm.keyValidation.collectAsState()
            val keyError by vm.keyError.collectAsState()
            var keyInput by remember { mutableStateOf("") }
            Spacer(Modifier.height(10.dp))

            GlassButton(
                text = if (useCustom) "使用公益 API" else "当前：公益 API（1243b485…）",
                onClick = { vm.usePublicApi() },
            )
            Spacer(Modifier.height(8.dp))
            GlassTextField(
                value = keyInput,
                onValueChange = { keyInput = it },
                placeholder = "输入自定义 VirusTotal API Key",
            )
            keyError?.let {
                Text(it, fontSize = 12.sp, color = DangerRed)
                Spacer(Modifier.height(4.dp))
            }
            if (validation == true) {
                Text("校验通过，Key 已加密保存", fontSize = 12.sp, color = Color(0xFF34C77B))
                Spacer(Modifier.height(4.dp))
            }
            Spacer(Modifier.height(6.dp))
            GlassButton(
                text = if (busy) "校验中…" else "校验并保存自定义 Key",
                onClick = { vm.saveCustomKey(keyInput) },
            )
        }
        Spacer(Modifier.height(14.dp))

        // ---- 扫描偏好（隐私模式） ----
        val privacy by vm.privacyHashOnly.collectAsState()
        GlassCard(pulseKey = privacy) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Dns, null, tint = Color(0xFF6FD8FF))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("隐私模式（只传哈希）", fontWeight = FontWeight.SemiBold)
                    Text(
                        "开启后不上传 APK 文件，仅用 SHA-256 查询库内已有报告；未收录的文件无法获得结果",
                        fontSize = 12.sp, color = Color(0xFF8C96B0),
                    )
                }
                Switch(checked = privacy, onCheckedChange = { vm.setPrivacyHashOnly(it) })
            }
        }
        Spacer(Modifier.height(14.dp))

        // ---- 网页防护 DNS ----
        var dnsInput by remember { mutableStateOf("") }
        val dnsSaved by vm.dnsServer.collectAsState()
        GlassCard {
            Text("网页防护 DNS 服务器", fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text("当前：$dnsSaved（默认 52.80.60.30，可自定义）", fontSize = 12.sp, color = Color(0xFF8C96B0))
            Spacer(Modifier.height(8.dp))
            GlassTextField(
                value = dnsInput,
                onValueChange = { dnsInput = it },
                placeholder = "输入新 DNS IPv4 地址，如 223.5.5.5",
            )
            Spacer(Modifier.height(8.dp))
            GlassButton(text = "保存 DNS", onClick = { vm.setDnsServer(dnsInput) })
        }
        Spacer(Modifier.height(14.dp))

        // ---- 减弱动效 ----
        val reduce by vm.reduceMotion.collectAsState()
        GlassCard(pulseKey = reduce) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("减弱动效", fontWeight = FontWeight.SemiBold)
                    Text(
                        "关闭液态流动与模糊，改为静态半透明卡片（弱机省电；同时自动尊重系统「移除动画」设置）",
                        fontSize = 12.sp, color = Color(0xFF8C96B0),
                    )
                }
                Switch(checked = reduce, onCheckedChange = { vm.setReduceMotion(it) })
            }
        }
        Spacer(Modifier.height(14.dp))

        // ---- QQ 交流群 ----
        GlassCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Rounded.Groups, null, tint = Color(0xFFFFB74D))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("加入 QQ 交流群", fontWeight = FontWeight.SemiBold)
                    Text("群号 418916519 · 反馈问题 / 交流使用技巧", fontSize = 12.sp, color = Color(0xFF8C96B0))
                }
            }
            Spacer(Modifier.height(10.dp))
            Row {
                GlassButton(text = "一键加群", onClick = { vm.joinQQGroup() }, modifier = Modifier.weight(1f))
                Spacer(Modifier.width(10.dp))
                GlassButton(text = "复制链接", onClick = { vm.copyGroupLink() }, modifier = Modifier.weight(1f))
            }
        }

        Spacer(Modifier.height(14.dp))
        Text(
            "安全护盾 v1.0.0 · 扫描能力基于 VirusTotal API",
            fontSize = 11.sp,
            color = Color(0xFF8C96B0),
            modifier = Modifier.fillMaxWidth().padding(bottom = 100.dp),
        )
    }
}
