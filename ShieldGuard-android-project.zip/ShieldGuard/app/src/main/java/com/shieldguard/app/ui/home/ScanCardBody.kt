package com.shieldguard.app.ui.home

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.InstallMobile
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shieldguard.app.data.db.Verdict
import com.shieldguard.app.data.prefs.SortMode
import com.shieldguard.app.ui.components.DropletCheckbox
import com.shieldguard.app.ui.components.EmptyState
import com.shieldguard.app.ui.components.GlassButton
import com.shieldguard.app.ui.components.GlassSkeleton
import com.shieldguard.app.ui.components.SegmentedGlassControl
import com.shieldguard.app.ui.components.VerdictChip

/**
 * 卡片 B 主体：玻璃分段控制器（已安装应用 / 选择安装包），切换带液态吸附（规范 5.3）。
 */
@Composable
fun ScanCardBody(
    vm: HomeViewModel,
    apkPicker: ActivityResultLauncher<Array<String>>,
    onOpenScanCenter: () -> Unit,
) {
    var segment by remember { mutableStateOf(0) }
    val selectedCount by vm.selected.collectAsState()
    val scanEnabled by vm.scanEnabled.collectAsState()

    Column(Modifier.padding(top = 12.dp)) {
        SegmentedGlassControl(
            options = listOf("已安装应用", "选择安装包"),
            selectedIndex = segment,
            onSelect = { segment = it },
            modifier = Modifier.fillMaxWidth(),
        )

        if (segment == 0) InstalledAppsSection(vm)
        else PickedApksSection(vm, apkPicker)

        Spacer(Modifier.height(12.dp))
        GlassButton(
            text = "开始扫描" + if (selectedCount.isNotEmpty()) "（已选 ${selectedCount.size} 个）" else "",
            onClick = {
                vm.startScan()
                onOpenScanCenter()
            },
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

@Composable
private fun InstalledAppsSection(vm: HomeViewModel) {
    val apps by vm.visibleApps.collectAsState()
    val loading by vm.appsLoading.collectAsState()
    val query by vm.query.collectAsState()
    val sortMode by vm.sortMode.collectAsState()
    val ignoreSystem by vm.ignoreSystemApps.collectAsState()
    val selected by vm.selected.collectAsState()
    val results by vm.scanResults.collectAsState()

    Column {
        OutlinedTextField(
            value = query,
            onValueChange = { vm.setQuery(it) },
            placeholder = { Text("搜索应用", fontSize = 13.sp) },
            leadingIcon = { Icon(Icons.Rounded.Search, null, Modifier.size(18.dp)) },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedContainerColor = Color.White.copy(alpha = 0.06f),
                focusedContainerColor = Color.White.copy(alpha = 0.10f),
            ),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
        )
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = sortMode == SortMode.INSTALL_TIME,
                onClick = { vm.setSortMode(SortMode.INSTALL_TIME) },
                label = { Text("按安装时间", fontSize = 12.sp) },
            )
            FilterChip(
                selected = sortMode == SortMode.SIZE,
                onClick = { vm.setSortMode(SortMode.SIZE) },
                label = { Text("按大小", fontSize = 12.sp) },
            )
            FilterChip(
                selected = ignoreSystem,
                onClick = { vm.setIgnoreSystem(!ignoreSystem) },
                label = { Text("忽略系统应用", fontSize = 12.sp) },
            )
        }
        Spacer(Modifier.height(8.dp))

        when {
            // 骨架屏玻璃 shimmer 加载态（规范 6 三态）
            loading -> Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                repeat(4) { GlassSkeleton(Modifier.fillMaxWidth().height(52.dp)) }
            }
            // 空状态
            apps.isEmpty() -> EmptyState("没有匹配的应用")
            else -> LazyColumn(
                Modifier
                    .fillMaxWidth()
                    .height(300.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                items(apps, key = { it.packageName }) { app ->
                    val result = results.firstOrNull { it.targetKey == "pkg:${app.packageName}" }
                    AppRow(
                        app = app,
                        checked = selected.contains(app.packageName),
                        verdict = result?.verdict,
                        onToggle = { vm.toggleSelect(app.packageName) },
                    )
                }
            }
        }
    }
}

@Composable
private fun AppRow(app: AppEntry, checked: Boolean, verdict: Int?, onToggle: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color.White.copy(alpha = 0.05f))
            .clickable { onToggle() }
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        app.icon?.let {
            Image(
                it.asImageBitmap(), null,
                Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(9.dp)),
            )
        } ?: Box(
            Modifier
                .size(36.dp)
                .clip(RoundedCornerShape(9.dp))
                .background(Color.White.copy(alpha = 0.10f)),
        )
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text(app.label, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                "${app.sizeBytes / 1024 / 1024} MB · ${app.packageName}",
                fontSize = 11.sp,
                color = Color(0xFF8C96B0),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        // 上次扫描徽标（绿=安全 黄=可疑 红=报毒）
        if (verdict != null) VerdictChip(verdict)
        Spacer(Modifier.width(8.dp))
        DropletCheckbox(checked = checked, onCheckedChange = { onToggle() })
    }
}

@Composable
private fun PickedApksSection(
    vm: HomeViewModel,
    apkPicker: ActivityResultLauncher<Array<String>>,
) {
    val apks by vm.pickedApks.collectAsState()
    val results by vm.scanResults.collectAsState()

    Column {
        GlassButton(
            text = "选择安装包（可多选）",
            onClick = { apkPicker.launch(arrayOf("*/*")) }, // EXTRA_ALLOW_MULTIPLE 由契约内置
            modifier = Modifier.fillMaxWidth(),
        )
        Spacer(Modifier.height(8.dp))
        if (apks.isEmpty()) {
            EmptyState("尚未选择安装包 · 权限已持久化，进程重启不丢失")
        } else {
            LazyColumn(
                Modifier
                    .fillMaxWidth()
                    .height(300.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                items(apks, key = { it.uriString }) { apk ->
                    val result = results.firstOrNull { it.targetKey == "uri:${apk.uriString}" }
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color.White.copy(alpha = 0.05f))
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            Icons.Rounded.InstallMobile, null,
                            tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp),
                        )
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(apk.displayName, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                "${apk.sizeBytes / 1024 / 1024} MB · ${apk.sourceHint}",
                                fontSize = 11.sp, color = Color(0xFF8C96B0),
                            )
                        }
                        if (result != null) VerdictChip(result.verdict)
                        // 「安装」按钮：报毒默认置灰，二次确认解锁（规范 2 卡片 B）
                        InstallButton(
                            maliciousLocked = result?.verdict == Verdict.MALICIOUS,
                            uriString = apk.uriString,
                        )
                        IconButton(onClick = { vm.removePicked(apk.uriString) }, modifier = Modifier.size(26.dp)) {
                            Icon(Icons.Rounded.Close, "移除", Modifier.size(15.dp), tint = Color(0xFF8C96B0))
                        }
                    }
                }
            }
        }
    }
}

/**
 * 安装按钮：报毒 → 置灰外观；点击 → 二次确认弹窗；确认 → 解锁，再点才真正安装。
 */
@Composable
private fun InstallButton(maliciousLocked: Boolean, uriString: String) {
    val context = LocalContext.current
    var unlocked by remember(uriString) { mutableStateOf(false) }
    var showConfirm by remember { mutableStateOf(false) }

    TextButton(
        // 报毒未解锁时保持可点击（点击弹二次确认），仅视觉置灰
        enabled = true,
        onClick = {
            if (maliciousLocked && !unlocked) {
                showConfirm = true
            } else {
                runCatching {
                    context.startActivity(
                        Intent(Intent.ACTION_INSTALL_PACKAGE)
                            .setData(Uri.parse(uriString))
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION),
                    )
                }
            }
        },
    ) {
        Text(
            if (maliciousLocked && !unlocked) "已置灰" else "安装",
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = if (maliciousLocked && !unlocked) Color(0xFF8C96B0) else MaterialTheme.colorScheme.primary,
        )
    }

    if (showConfirm) {
        AlertDialog(
            onDismissRequest = { showConfirm = false },
            title = { Text("高危安装确认") },
            text = { Text("该安装包已被多款引擎报毒。确认识别风险并解锁安装？") },
            confirmButton = {
                TextButton(onClick = { unlocked = true; showConfirm = false }) { Text("解锁安装") }
            },
            dismissButton = {
                TextButton(onClick = { showConfirm = false }) { Text("取消") }
            },
        )
    }
}
