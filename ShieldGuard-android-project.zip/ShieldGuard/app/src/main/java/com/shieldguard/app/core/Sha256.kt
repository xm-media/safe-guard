package com.shieldguard.app.core

import java.io.File
import java.io.InputStream
import java.security.MessageDigest

/** SHA-256 工具：流式读取，避免大文件整块载入内存 */
object Sha256 {

    fun of(file: File): String = file.inputStream().use { of(it) }

    fun of(stream: InputStream): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val buf = ByteArray(64 * 1024)
        while (true) {
            val n = stream.read(buf)
            if (n < 0) break
            digest.update(buf, 0, n)
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}
