# ---- 混淆规则：保留序列化模型，防止 kSerialization 反射改名导致字段丢失 ----
-keepattributes *Annotation*, InnerClasses, Signature
-dontnote kotlinx.serialization.**
-keepclassmembers class kotlinx.serialization.json.** { *** Companion; }
-keepclasseswithmembers class kotlinx.serialization.json.** { kotlinx.serialization.KSerializer serializer(...); }
-keep,includedescriptorclasses class com.shieldguard.app.**$$serializer { *; }
-keepclassmembers class com.shieldguard.app.** { *** Companion; }
-keepclasseswithmembers class com.shieldguard.app.** { kotlinx.serialization.KSerializer serializer(...); }

# OkHttp / Okio
-dontwarn okhttp3.**
-dontwarn okio.**
-dontwarn javax.annotation.**
-keepnames class okhttp3.internal.publicsuffix.PublicSuffixDatabase

# WorkManager 由 AAPT 自动保留；DataStore 使用 proto-free preferences，无需额外规则
